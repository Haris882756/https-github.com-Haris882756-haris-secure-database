import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, a as AlertDialogDescription, c as AlertDialogTitle, d as DialogDescription, f as DialogOverlay, g as require_jsx_runtime, i as AlertDialogContent, l as Dialog, m as DialogTitle, n as AlertDialogAction, o as AlertDialogOverlay, p as DialogPortal, r as AlertDialogCancel, s as AlertDialogPortal, t as AlertDialog, u as DialogContent } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as Search, c as KeyRound, d as EyeOff, f as Database, i as ShieldCheck, l as HardDrive, m as Archive, n as Table2, o as Plus, p as ArrowLeft, r as Shield, s as LogOut, u as Eye } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as format } from "../_libs/date-fns.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BNoek_Dh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-md px-4 text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink/35 disabled:pointer-events-none disabled:opacity-50", {
	variants: { variant: {
		primary: "bg-ink text-paper hover:bg-ink/90",
		secondary: "border border-line bg-card text-ink hover:bg-paper",
		ghost: "bg-transparent text-ink hover:bg-ink/5",
		danger: "bg-danger text-paper hover:bg-danger/90"
	} },
	defaultVariants: { variant: "primary" }
});
function Button({ className, variant, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({ variant }), "min-h-11", className),
		...props
	});
}
function Modal({ open, onOpenChange, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "modal-overlay fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "modal-content max-h-full w-full max-w-lg overflow-y-auto rounded-xl border border-line bg-card p-6 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "font-display text-2xl text-ink",
						children: title
					}),
					description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-2 text-sm text-muted",
						children: description
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "sr-only",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children
					})
				]
			})
		})] })
	});
}
function ConfirmDialog({ open, title, body, confirmLabel, destructive = false, pending = false, onConfirm, onOpenChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, { className: "modal-overlay fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
				className: "modal-content w-full max-w-md rounded-xl border border-line bg-card p-6 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
						className: "font-display text-2xl text-ink",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
						className: "mt-2 text-sm text-muted",
						children: body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								children: "Cancel"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: destructive ? "danger" : "primary",
								disabled: pending,
								onClick: (event) => {
									event.preventDefault();
									onConfirm();
								},
								children: confirmLabel
							})
						})]
					})
				]
			})
		})] })
	});
}
function downloadText(filename, text) {
	const blob = new Blob([text], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
async function readJsonFile(file) {
	if (file.size > 5e6) throw new Error("That file is larger than 5 MB.");
	const text = await file.text();
	try {
		return JSON.parse(text);
	} catch {
		throw new Error("That file is not valid JSON.");
	}
}
var IDENT = /^[A-Za-z][A-Za-z0-9_]{0,39}$/;
var DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
var ACCOUNT_KEY = "haris.account.v1";
var LOCKOUT_KEY = "haris.lockout.v1";
var WORKSPACE_FORMAT = "haris-secure-database-builder";
var SEALED_FORMAT = "haris-sealed-vault";
var COLUMN_LABEL = {
	text: "Text",
	number: "Number",
	date: "Date",
	boolean: "Yes / No"
};
function emptyVault() {
	return {
		databases: [],
		activity: []
	};
}
function freshLockout() {
	return {
		failed: 0,
		lockedUntil: 0,
		sinceUnlock: 0
	};
}
function byName(a, b) {
	return a.name.localeCompare(b.name, void 0, { sensitivity: "base" });
}
function countTables(vault) {
	return vault.databases.reduce((n, db) => n + db.tables.length, 0);
}
function countRows(vault) {
	return vault.databases.reduce((n, db) => n + db.tables.reduce((m, table) => m + table.rows.length, 0), 0);
}
function countRowsIn(db) {
	return db.tables.reduce((n, table) => n + table.rows.length, 0);
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isCell(value) {
	return value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value);
}
function isAccountFile(value) {
	if (!isRecord(value) || value.version !== 1) return false;
	return [
		"username",
		"passSalt",
		"passHash",
		"wrapSalt",
		"wrapIv",
		"wrappedKey",
		"vaultIv",
		"vault"
	].every((key) => typeof value[key] === "string" && value[key].length > 0);
}
function coerce(column, value) {
	if (column.type === "text") {
		if (typeof value !== "string") return null;
		return value.slice(0, 1e4);
	}
	if (column.type === "number") return typeof value === "number" && Number.isFinite(value) ? value : null;
	if (column.type === "date") return typeof value === "string" && DATE_RE.test(value) ? value : null;
	return typeof value === "boolean" ? value : null;
}
function parseColumn(value) {
	if (!isRecord(value)) throw new Error("This file is not a Haris workspace export.");
	if (typeof value.id !== "string" || value.id.length < 8 || value.id.length > 80) throw new Error("This file is not a Haris workspace export.");
	if (typeof value.name !== "string" || !IDENT.test(value.name)) throw new Error("A column name in that file is not allowed.");
	if (value.type !== "text" && value.type !== "number" && value.type !== "date" && value.type !== "boolean") throw new Error("A column type in that file is not allowed.");
	return {
		id: value.id,
		name: value.name,
		type: value.type
	};
}
function parseRow(columns, value) {
	if (!isRecord(value)) throw new Error("This file is not a Haris workspace export.");
	if (typeof value.id !== "string" || value.id.length < 8 || value.id.length > 80) throw new Error("This file is not a Haris workspace export.");
	if (typeof value.createdAt !== "number" || typeof value.updatedAt !== "number") throw new Error("This file is not a Haris workspace export.");
	const rawValues = isRecord(value.values) ? value.values : {};
	const values = {};
	for (const column of columns) {
		const cell = rawValues[column.id];
		if (cell !== void 0 && !isCell(cell)) throw new Error("A record in that file has a value this workspace cannot store.");
		values[column.id] = coerce(column, cell);
	}
	return {
		id: value.id,
		values,
		createdAt: value.createdAt,
		updatedAt: value.updatedAt
	};
}
function parseTable(value) {
	if (!isRecord(value) || !Array.isArray(value.columns) || !Array.isArray(value.rows)) throw new Error("This file is not a Haris workspace export.");
	if (typeof value.id !== "string" || typeof value.name !== "string" || typeof value.createdAt !== "number") throw new Error("This file is not a Haris workspace export.");
	if (!IDENT.test(value.name)) throw new Error("A table name in that file is not allowed.");
	if (value.columns.length < 1 || value.columns.length > 12) throw new Error("Each table needs between 1 and 12 columns.");
	if (value.rows.length > 2e3) throw new Error("A table in that file has too many records.");
	const columns = value.columns.map(parseColumn);
	const seen = /* @__PURE__ */ new Set();
	for (const column of columns) {
		const key = column.name.toLowerCase();
		if (seen.has(key)) throw new Error("A table in that file repeats a column name.");
		seen.add(key);
	}
	return {
		id: value.id,
		name: value.name,
		columns,
		rows: value.rows.map((row) => parseRow(columns, row)),
		createdAt: value.createdAt
	};
}
function parseDatabase(value) {
	if (!isRecord(value) || !Array.isArray(value.tables)) throw new Error("This file is not a Haris workspace export.");
	if (typeof value.id !== "string" || typeof value.name !== "string" || typeof value.description !== "string" || typeof value.createdAt !== "number") throw new Error("This file is not a Haris workspace export.");
	const name = value.name.trim();
	if (!name || name.length > 80) throw new Error("A database name in that file is not allowed.");
	if (value.description.length > 240) throw new Error("A description in that file is too long.");
	if (value.tables.length > 50) throw new Error("A database in that file has too many tables.");
	const tables = value.tables.map(parseTable).sort(byName);
	const seen = /* @__PURE__ */ new Set();
	for (const table of tables) {
		const key = table.name.toLowerCase();
		if (seen.has(key)) throw new Error("A database in that file repeats a table name.");
		seen.add(key);
	}
	return {
		id: value.id,
		name,
		description: value.description.trim(),
		tables,
		createdAt: value.createdAt
	};
}
function parseActivity(value) {
	if (!Array.isArray(value)) return [];
	return value.slice(0, 200).flatMap((item) => {
		if (!isRecord(item)) return [];
		if (typeof item.id !== "string" || typeof item.event !== "string" || typeof item.at !== "number") return [];
		return [{
			id: item.id,
			event: item.event.slice(0, 500),
			at: item.at
		}];
	});
}
function parseWorkspaceExport(value) {
	if (!isRecord(value) || value.format !== "haris-secure-database-builder" || value.version !== 1) throw new Error("This file is not a Haris workspace export.");
	if (!Array.isArray(value.databases)) throw new Error("This file is not a Haris workspace export.");
	if (value.databases.length > 100) throw new Error("That export has too many databases.");
	const databases = value.databases.map(parseDatabase).sort(byName);
	const seen = /* @__PURE__ */ new Set();
	for (const db of databases) {
		const key = db.name.toLowerCase();
		if (seen.has(key)) throw new Error("That export repeats a database name.");
		seen.add(key);
	}
	return {
		databases,
		activity: parseActivity(value.activity)
	};
}
function parseSealedBackup(value) {
	if (!isRecord(value) || value.format !== "haris-sealed-vault" || value.version !== 1) throw new Error("This file is not a sealed Haris vault.");
	if (!isAccountFile(value.account)) throw new Error("This file is not a sealed Haris vault.");
	return value.account;
}
function formatCell(value, type) {
	if (value === null || value === "") return "—";
	if (type === "boolean") return value === true ? "Yes" : "No";
	return String(value);
}
var ITERATIONS = 21e4;
function asBuffer(bytes) {
	return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}
function randomBytes(size) {
	const bytes = new Uint8Array(size);
	crypto.getRandomValues(bytes);
	return bytes;
}
function encodeBase64(bytes) {
	let binary = "";
	const chunk = 32768;
	for (let index = 0; index < bytes.length; index += chunk) binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
	return btoa(binary);
}
function decodeBase64(value) {
	const binary = atob(value);
	const bytes = new Uint8Array(binary.length);
	for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
	return bytes;
}
function constantTimeEquals(a, b) {
	const length = Math.max(a.length, b.length);
	let diff = a.length ^ b.length;
	for (let index = 0; index < length; index += 1) diff |= (a.charCodeAt(index) || 0) ^ (b.charCodeAt(index) || 0);
	return diff === 0;
}
async function importPassword(password) {
	return crypto.subtle.importKey("raw", asBuffer(new TextEncoder().encode(password)), "PBKDF2", false, ["deriveBits", "deriveKey"]);
}
async function stretchBits(password, salt) {
	const key = await importPassword(password);
	const bits = await crypto.subtle.deriveBits({
		name: "PBKDF2",
		salt: asBuffer(salt),
		iterations: ITERATIONS,
		hash: "SHA-256"
	}, key, 256);
	return new Uint8Array(bits);
}
async function stretchAes(password, salt) {
	const key = await importPassword(password);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt: asBuffer(salt),
		iterations: ITERATIONS,
		hash: "SHA-256"
	}, key, {
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
}
async function aesEncrypt(key, iv, data) {
	const encrypted = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv: asBuffer(iv)
	}, key, asBuffer(data));
	return new Uint8Array(encrypted);
}
async function aesDecrypt(key, iv, data) {
	const decrypted = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv: asBuffer(iv)
	}, key, asBuffer(data));
	return new Uint8Array(decrypted);
}
function isVault(value) {
	if (typeof value !== "object" || value === null) return false;
	const vault = value;
	return Array.isArray(vault.databases) && Array.isArray(vault.activity);
}
async function encryptVault(key, vault) {
	const iv = randomBytes(12);
	const sealed = await aesEncrypt(key, iv, new TextEncoder().encode(JSON.stringify(vault)));
	return {
		vaultIv: encodeBase64(iv),
		vault: encodeBase64(sealed)
	};
}
async function sealNewAccount(username, password, vault = emptyVault()) {
	const passSalt = randomBytes(16);
	const wrapSalt = randomBytes(16);
	const passHash = await stretchBits(password, passSalt);
	const dataKey = await crypto.subtle.generateKey({
		name: "AES-GCM",
		length: 256
	}, true, ["encrypt", "decrypt"]);
	const raw = new Uint8Array(await crypto.subtle.exportKey("raw", dataKey));
	const wrapKey = await stretchAes(password, wrapSalt);
	const wrapIv = randomBytes(12);
	const wrapped = await aesEncrypt(wrapKey, wrapIv, raw);
	const sealed = await encryptVault(dataKey, vault);
	return {
		key: dataKey,
		account: {
			version: 1,
			username,
			passSalt: encodeBase64(passSalt),
			passHash: encodeBase64(passHash),
			wrapSalt: encodeBase64(wrapSalt),
			wrapIv: encodeBase64(wrapIv),
			wrappedKey: encodeBase64(wrapped),
			vaultIv: sealed.vaultIv,
			vault: sealed.vault
		}
	};
}
async function passwordMatches(account, password) {
	return constantTimeEquals(encodeBase64(await stretchBits(password, decodeBase64(account.passSalt))), account.passHash);
}
async function openAccount(account, password) {
	if (!await passwordMatches(account, password)) return null;
	const wrapKey = await stretchAes(password, decodeBase64(account.wrapSalt));
	let raw;
	try {
		raw = await aesDecrypt(wrapKey, decodeBase64(account.wrapIv), decodeBase64(account.wrappedKey));
	} catch {
		throw new Error("The vault could not be unlocked.");
	}
	const dataKey = await crypto.subtle.importKey("raw", asBuffer(raw), { name: "AES-GCM" }, true, ["encrypt", "decrypt"]);
	let plain;
	try {
		plain = await aesDecrypt(dataKey, decodeBase64(account.vaultIv), decodeBase64(account.vault));
	} catch {
		throw new Error("The vault could not be read.");
	}
	let parsed;
	try {
		parsed = JSON.parse(new TextDecoder().decode(plain));
	} catch {
		throw new Error("The vault could not be read.");
	}
	if (!isVault(parsed)) throw new Error("The vault could not be read.");
	return {
		key: dataKey,
		vault: parsed
	};
}
async function sealVault(account, key, vault) {
	const sealed = await encryptVault(key, vault);
	return {
		...account,
		vaultIv: sealed.vaultIv,
		vault: sealed.vault
	};
}
async function rewrapAccount(account, dataKey, password) {
	const passSalt = randomBytes(16);
	const wrapSalt = randomBytes(16);
	const passHash = await stretchBits(password, passSalt);
	const raw = new Uint8Array(await crypto.subtle.exportKey("raw", dataKey));
	const wrapKey = await stretchAes(password, wrapSalt);
	const wrapIv = randomBytes(12);
	const wrapped = await aesEncrypt(wrapKey, wrapIv, raw);
	return {
		...account,
		passSalt: encodeBase64(passSalt),
		passHash: encodeBase64(passHash),
		wrapSalt: encodeBase64(wrapSalt),
		wrapIv: encodeBase64(wrapIv),
		wrappedKey: encodeBase64(wrapped)
	};
}
function readLockout() {
	try {
		const raw = localStorage.getItem(LOCKOUT_KEY);
		if (!raw) return freshLockout();
		const parsed = JSON.parse(raw);
		return {
			failed: Number(parsed.failed) || 0,
			lockedUntil: Number(parsed.lockedUntil) || 0,
			sinceUnlock: Number(parsed.sinceUnlock) || 0
		};
	} catch {
		return freshLockout();
	}
}
function writeLockout(lockout) {
	localStorage.setItem(LOCKOUT_KEY, JSON.stringify(lockout));
}
function readAccount() {
	try {
		const raw = localStorage.getItem(ACCOUNT_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return isAccountFile(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function writeAccount(account) {
	try {
		localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account));
	} catch {
		throw new Error("Could not save. This browser may be out of storage space.");
	}
}
function withLog(vault, event) {
	const entry = {
		id: crypto.randomUUID(),
		event,
		at: Date.now()
	};
	return {
		...vault,
		activity: [entry, ...vault.activity].slice(0, 200)
	};
}
function requireOpen(state) {
	if (!state.account || !state.dataKey || state.status !== "open") throw new Error("The workspace is locked.");
	return {
		account: state.account,
		dataKey: state.dataKey,
		vault: state.vault
	};
}
var useVault = create((set, get) => {
	async function commit(vault, event) {
		const open = requireOpen(get());
		const next = event ? withLog(vault, event) : vault;
		const sealed = await sealVault(open.account, open.dataKey, next);
		writeAccount(sealed);
		set({
			account: sealed,
			vault: next
		});
	}
	return {
		status: "booting",
		busy: false,
		account: null,
		vault: emptyVault(),
		dataKey: null,
		lockout: freshLockout(),
		screen: { name: "home" },
		hydrate: () => {
			if (get().status !== "booting") return;
			const account = readAccount();
			set({
				account,
				lockout: readLockout(),
				status: account ? "locked" : "setup",
				vault: emptyVault(),
				dataKey: null
			});
		},
		createAccount: async (username, password) => {
			const trimmed = username.trim();
			if (!trimmed) throw new Error("Enter a username.");
			if (trimmed.length > 40) throw new Error("Use a shorter username.");
			if (password.length < 10) throw new Error("Use at least 10 password characters.");
			set({ busy: true });
			try {
				const { account } = await sealNewAccount(trimmed, password, withLog(emptyVault(), "Administrator account created"));
				writeAccount(account);
				writeLockout(freshLockout());
				set({
					account,
					status: "locked",
					busy: false,
					dataKey: null,
					vault: emptyVault(),
					lockout: freshLockout(),
					screen: { name: "home" }
				});
			} catch (error) {
				set({ busy: false });
				if (error instanceof Error && error.message.startsWith("Could not save")) throw error;
				throw new Error("Could not create the account.");
			}
		},
		unlock: async (password) => {
			const account = get().account ?? readAccount();
			if (!account) {
				set({
					status: "setup",
					account: null
				});
				throw new Error("Create an administrator account first.");
			}
			const lockout = get().lockout;
			if (Date.now() < lockout.lockedUntil) throw new Error("Too many attempts. Wait a little and try again.");
			set({ busy: true });
			try {
				const opened = await openAccount(account, password);
				if (!opened) {
					const failed = lockout.failed + 1;
					const sinceUnlock = lockout.sinceUnlock + 1;
					const next = failed >= 5 ? {
						failed: 0,
						lockedUntil: Date.now() + 3e4,
						sinceUnlock
					} : {
						failed,
						lockedUntil: 0,
						sinceUnlock
					};
					writeLockout(next);
					set({
						busy: false,
						lockout: next,
						account
					});
					throw new Error("Sign-in failed. Check your details.");
				}
				let vault = opened.vault;
				if (lockout.sinceUnlock > 0) {
					const count = lockout.sinceUnlock;
					vault = withLog(vault, count === 1 ? "1 failed sign-in attempt" : `${count} failed sign-in attempts`);
				}
				vault = withLog(vault, "Signed in");
				const sealed = await sealVault(account, opened.key, vault);
				writeAccount(sealed);
				const cleared = freshLockout();
				writeLockout(cleared);
				set({
					status: "open",
					busy: false,
					account: sealed,
					dataKey: opened.key,
					vault,
					lockout: cleared,
					screen: { name: "home" }
				});
			} catch (error) {
				set({ busy: false });
				throw error;
			}
		},
		lock: () => {
			const account = readAccount();
			set({
				status: account ? "locked" : "setup",
				account,
				dataKey: null,
				vault: emptyVault(),
				screen: { name: "home" },
				busy: false
			});
		},
		erase: () => {
			localStorage.removeItem(ACCOUNT_KEY);
			localStorage.removeItem(LOCKOUT_KEY);
			set({
				status: "setup",
				account: null,
				dataKey: null,
				vault: emptyVault(),
				lockout: freshLockout(),
				screen: { name: "home" },
				busy: false
			});
		},
		changePassword: async (current, next) => {
			const open = requireOpen(get());
			if (next.length < 10) throw new Error("Use at least 10 characters for the new password.");
			set({ busy: true });
			try {
				if (!await passwordMatches(open.account, current)) {
					set({ busy: false });
					throw new Error("Current password is incorrect.");
				}
				const rewrapped = await rewrapAccount(open.account, open.dataKey, next);
				const logged = withLog(open.vault, "Administrator password changed");
				const sealed = await sealVault(rewrapped, open.dataKey, logged);
				writeAccount(sealed);
				set({
					account: sealed,
					vault: logged,
					busy: false
				});
			} catch (error) {
				set({ busy: false });
				throw error;
			}
		},
		go: (screen) => set({ screen }),
		createDatabase: async (nameRaw, descriptionRaw) => {
			const name = nameRaw.trim();
			const description = descriptionRaw.trim();
			if (!name) throw new Error("Enter a database name.");
			if (name.length > 80) throw new Error("Use a shorter database name.");
			if (description.length > 240) throw new Error("Use a shorter description.");
			const { vault } = requireOpen(get());
			if (vault.databases.length >= 100) throw new Error("This workspace already has 100 databases.");
			if (vault.databases.some((db) => db.name.toLowerCase() === name.toLowerCase())) throw new Error("That database name already exists.");
			const id = crypto.randomUUID();
			const database = {
				id,
				name,
				description,
				tables: [],
				createdAt: Date.now()
			};
			await commit({
				...vault,
				databases: [...vault.databases, database].sort(byName)
			}, `Database created: ${name}`);
			return id;
		},
		deleteDatabase: async (id) => {
			const { vault } = requireOpen(get());
			const database = vault.databases.find((item) => item.id === id);
			if (!database) return;
			await commit({
				...vault,
				databases: vault.databases.filter((item) => item.id !== id)
			}, `Database deleted: ${database.name}`);
		},
		createTable: async (databaseId, nameRaw, columnsRaw) => {
			const name = nameRaw.trim();
			if (!IDENT.test(name)) throw new Error("Use a letter first, then letters, numbers, or underscore.");
			if (columnsRaw.length < 1 || columnsRaw.length > 12) throw new Error("Add between 1 and 12 columns.");
			const columns = [];
			const seen = /* @__PURE__ */ new Set();
			for (const column of columnsRaw) {
				const columnName = column.name.trim();
				if (!IDENT.test(columnName)) throw new Error("Column names start with a letter, then letters, numbers, or underscore.");
				const key = columnName.toLowerCase();
				if (seen.has(key)) throw new Error("Column names must be unique.");
				seen.add(key);
				columns.push({
					id: crypto.randomUUID(),
					name: columnName,
					type: column.type
				});
			}
			const { vault } = requireOpen(get());
			const database = vault.databases.find((item) => item.id === databaseId);
			if (!database) throw new Error("That database is no longer here.");
			if (database.tables.length >= 50) throw new Error("This database already has 50 tables.");
			if (database.tables.some((table) => table.name.toLowerCase() === name.toLowerCase())) throw new Error("That table already exists.");
			const id = crypto.randomUUID();
			const table = {
				id,
				name,
				columns,
				rows: [],
				createdAt: Date.now()
			};
			await commit({
				...vault,
				databases: vault.databases.map((item) => item.id === databaseId ? {
					...item,
					tables: [...item.tables, table].sort(byName)
				} : item)
			}, `Table created: ${database.name} / ${name}`);
			return id;
		},
		deleteTable: async (databaseId, tableId) => {
			const { vault } = requireOpen(get());
			const database = vault.databases.find((item) => item.id === databaseId);
			const table = database?.tables.find((item) => item.id === tableId);
			if (!database || !table) return;
			await commit({
				...vault,
				databases: vault.databases.map((item) => item.id === databaseId ? {
					...item,
					tables: item.tables.filter((entry) => entry.id !== tableId)
				} : item)
			}, `Table deleted: ${database.name} / ${table.name}`);
		},
		saveRow: async (databaseId, tableId, rowId, values) => {
			const { vault } = requireOpen(get());
			const database = vault.databases.find((item) => item.id === databaseId);
			const table = database?.tables.find((item) => item.id === tableId);
			if (!database || !table) throw new Error("That table is no longer here.");
			const now = Date.now();
			let event = `Record added in ${database.name} / ${table.name}`;
			const rows = rowId ? table.rows.map((row) => {
				if (row.id !== rowId) return row;
				event = `Record edited in ${database.name} / ${table.name}`;
				return {
					...row,
					values,
					updatedAt: now
				};
			}) : [{
				id: crypto.randomUUID(),
				values,
				createdAt: now,
				updatedAt: now
			}, ...table.rows];
			if (!rowId && table.rows.length >= 2e3) throw new Error("This table already has 2,000 records.");
			await commit({
				...vault,
				databases: vault.databases.map((item) => item.id !== databaseId ? item : {
					...item,
					tables: item.tables.map((entry) => entry.id === tableId ? {
						...entry,
						rows
					} : entry)
				})
			}, event);
		},
		deleteRow: async (databaseId, tableId, rowId) => {
			const { vault } = requireOpen(get());
			const database = vault.databases.find((item) => item.id === databaseId);
			const table = database?.tables.find((item) => item.id === tableId);
			if (!database || !table) return;
			await commit({
				...vault,
				databases: vault.databases.map((item) => item.id !== databaseId ? item : {
					...item,
					tables: item.tables.map((entry) => entry.id === tableId ? {
						...entry,
						rows: entry.rows.filter((row) => row.id !== rowId)
					} : entry)
				})
			}, `Record deleted in ${database.name} / ${table.name}`);
		},
		replaceWorkspace: async (incoming) => {
			await commit(withLog(incoming, "Workspace imported from JSON"));
		},
		restoreSealed: (account) => {
			writeAccount(account);
			writeLockout(freshLockout());
			set({
				status: "locked",
				account,
				dataKey: null,
				vault: emptyVault(),
				lockout: freshLockout(),
				screen: { name: "home" },
				busy: false
			});
		}
	};
});
function BackupScreen() {
	const vault = useVault((state) => state.vault);
	const account = useVault((state) => state.account);
	const replaceWorkspace = useVault((state) => state.replaceWorkspace);
	const restoreSealed = useVault((state) => state.restoreSealed);
	const jsonRef = (0, import_react.useRef)(null);
	const sealedRef = (0, import_react.useRef)(null);
	const [pendingVault, setPendingVault] = (0, import_react.useState)(null);
	const [pendingSealed, setPendingSealed] = (0, import_react.useState)(false);
	const [sealedAccount, setSealedAccount] = (0, import_react.useState)(null);
	const [working, setWorking] = (0, import_react.useState)(false);
	const stored = typeof window === "undefined" ? "" : localStorage.getItem("haris.account.v1") ?? "";
	const kilobytes = Math.max(1, Math.round(stored.length / 1024));
	function exportJson() {
		const payload = {
			format: WORKSPACE_FORMAT,
			version: 1,
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			databases: vault.databases,
			activity: vault.activity
		};
		downloadText(`haris-workspace-${format(/* @__PURE__ */ new Date(), "yyyy-MM-dd")}.json`, JSON.stringify(payload, null, 2));
		toast("Readable export downloaded.");
	}
	function exportSealed() {
		if (!account) return;
		const payload = {
			format: SEALED_FORMAT,
			version: 1,
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			account
		};
		downloadText(`haris-sealed-${format(/* @__PURE__ */ new Date(), "yyyy-MM-dd")}.json`, JSON.stringify(payload));
		toast("Sealed vault downloaded.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Backup and restore"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-muted",
			children: "The copy in this browser is encrypted with your password. A sealed file keeps that lock. A readable JSON file does not — treat it like a printout."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm text-muted tabular-nums",
			children: [
				vault.databases.length,
				" databases · ",
				countTables(vault),
				" tables · ",
				countRows(vault),
				" records · about",
				" ",
				kilobytes,
				" KB sealed in this browser"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Sealed vault"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Move the encrypted workspace to another browser. Restoring it replaces the account on this browser, including the password that sealed the file."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: exportSealed,
							children: "Download sealed vault"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => sealedRef.current?.click(),
							children: "Restore sealed vault"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Readable JSON"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Export databases and the activity log as plain JSON. Import replaces the databases inside the current account. It does not change your password."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: exportJson,
							children: "Download JSON"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => jsonRef.current?.click(),
							children: "Import JSON"
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: jsonRef,
			type: "file",
			accept: "application/json,.json",
			className: "sr-only",
			onChange: (event) => {
				const file = event.target.files?.[0];
				event.target.value = "";
				if (!file) return;
				readJsonFile(file).then((data) => setPendingVault(parseWorkspaceExport(data))).catch((error) => toast(error instanceof Error ? error.message : "Could not read that file."));
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: sealedRef,
			type: "file",
			accept: "application/json,.json",
			className: "sr-only",
			onChange: (event) => {
				const file = event.target.files?.[0];
				event.target.value = "";
				if (!file) return;
				readJsonFile(file).then((data) => {
					setSealedAccount(parseSealedBackup(data));
					setPendingSealed(true);
				}).catch((error) => toast(error instanceof Error ? error.message : "Could not read that file."));
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: pendingVault !== null,
			title: "Replace the workspace?",
			body: pendingVault ? `This replaces your current databases with ${pendingVault.databases.length} databases, ${countTables(pendingVault)} tables, and ${countRows(pendingVault)} records.` : "",
			confirmLabel: "Import",
			pending: working,
			onOpenChange: (open) => {
				if (!open) setPendingVault(null);
			},
			onConfirm: () => {
				if (!pendingVault) return;
				setWorking(true);
				replaceWorkspace(pendingVault).then(() => {
					toast("Workspace imported.");
					setPendingVault(null);
				}).catch((error) => toast(error instanceof Error ? error.message : "Could not import.")).finally(() => setWorking(false));
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: pendingSealed,
			title: "Restore sealed vault?",
			body: `This replaces the administrator on this browser with ${sealedAccount?.username ?? "the backup account"}. You will need that vault's password to sign in.`,
			confirmLabel: "Restore",
			destructive: true,
			onOpenChange: (open) => {
				if (!open) {
					setPendingSealed(false);
					setSealedAccount(null);
				}
			},
			onConfirm: () => {
				if (!sealedAccount) return;
				restoreSealed(sealedAccount);
				setPendingSealed(false);
				setSealedAccount(null);
				toast("Sealed vault restored. Sign in with its password.");
			}
		})
	] });
}
var controlClass = "h-11 w-full rounded-md border border-line bg-card px-3 text-base text-ink outline-none placeholder:text-muted/80 focus-visible:ring-2 focus-visible:ring-ink/30";
function Label({ htmlFor, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor,
		className: "mb-1.5 block text-sm font-medium text-ink",
		children
	});
}
function Field({ label, htmlFor, hint, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor,
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-sm text-danger",
				role: "alert",
				children: error
			}) : hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-sm text-muted",
				children: hint
			}) : null
		]
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(controlClass, className),
		...props
	});
}
function PasswordInput({ className, ...props }) {
	const [visible, setVisible] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			...props,
			type: visible ? "text" : "password",
			className: cn("pr-12", className)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute top-0 right-0 flex h-11 w-11 items-center justify-center text-muted",
			onClick: () => setVisible((value) => !value),
			"aria-label": visible ? "Hide password" : "Show password",
			children: visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
		})]
	});
}
function BrandPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "hidden flex-col justify-between bg-ink px-12 py-14 text-paper lg:flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium tracking-widest text-paper/70",
				children: "HARIS PRO"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 max-w-md font-display text-5xl leading-tight",
				children: "Secure Database Builder"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-md text-lg text-paper/80",
				children: "A private workspace for databases you do not want sitting in a spreadsheet."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "grid max-w-md gap-5 text-sm leading-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
						className: "mt-0.5 size-5 shrink-0",
						"aria-hidden": "true"
					}), "Password-sealed with PBKDF2 and AES-GCM. The files themselves are encrypted."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, {
						className: "mt-0.5 size-5 shrink-0",
						"aria-hidden": "true"
					}), "Stored only in this browser. Nothing is uploaded."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
						className: "mt-0.5 size-5 shrink-0",
						"aria-hidden": "true"
					}), "Five wrong attempts pause sign-in for 30 seconds."]
				})
			]
		})]
	});
}
function GateFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-screen bg-paper lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "flex items-center justify-center px-4 py-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-widest text-muted",
						children: "HARIS PRO"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl text-ink",
						children: "Secure Database Builder"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "rounded-xl border border-line bg-card p-6 shadow-panel",
					children
				})]
			})
		})]
	});
}
function SetupScreen() {
	const createAccount = useVault((state) => state.createAccount);
	const busy = useVault((state) => state.busy);
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		if (!username.trim() || password.length < 10 || password !== confirm) {
			setError("Enter a username, use at least 10 password characters, and make both passwords match.");
			return;
		}
		try {
			await createAccount(username, password);
			toast("Account created. Please sign in.");
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not create the account.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl text-ink",
			children: "Create administrator"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "First-run setup. Choose your own password. If you forget it, this workspace cannot be recovered."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Administrator username",
					htmlFor: "username",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "username",
						name: "username",
						autoComplete: "username",
						value: username,
						onChange: (event) => setUsername(event.target.value),
						disabled: busy
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Create strong password",
					htmlFor: "new-password",
					hint: "At least 10 characters.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
						id: "new-password",
						name: "new-password",
						autoComplete: "new-password",
						value: password,
						onChange: (event) => setPassword(event.target.value),
						disabled: busy
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Confirm password",
					htmlFor: "confirm-password",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
						id: "confirm-password",
						name: "confirm-password",
						autoComplete: "new-password",
						value: confirm,
						onChange: (event) => setConfirm(event.target.value),
						disabled: busy
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm text-danger",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					disabled: busy,
					children: busy ? "Creating account…" : "Create secure account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "This can take a moment. The password is stretched on purpose."
				})
			]
		})
	] });
}
function LoginScreen() {
	const account = useVault((state) => state.account);
	const busy = useVault((state) => state.busy);
	const lockout = useVault((state) => state.lockout);
	const unlock = useVault((state) => state.unlock);
	const erase = useVault((state) => state.erase);
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const [eraseOpen, setEraseOpen] = (0, import_react.useState)(false);
	const [phrase, setPhrase] = (0, import_react.useState)("");
	const waiting = Math.max(0, lockout.lockedUntil - now);
	const locked = waiting > 0;
	(0, import_react.useEffect)(() => {
		if (!locked) return;
		const timer = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(timer);
	}, [locked]);
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		try {
			await unlock(password);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Sign-in failed. Check your details.");
			setPassword("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GateFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl text-ink",
			children: "Sign in"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Local sign-in. Works offline. Closing the tab locks the workspace."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6",
			onSubmit,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Administrator",
					htmlFor: "login-user",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "login-user",
						value: account?.username ?? "",
						readOnly: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Password",
					htmlFor: "password",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
						id: "password",
						name: "password",
						autoComplete: "current-password",
						value: password,
						onChange: (event) => setPassword(event.target.value),
						disabled: busy || locked
					})
				}),
				locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-4 text-sm text-danger",
					role: "alert",
					children: [
						"Too many attempts. Try again in ",
						Math.ceil(waiting / 1e3),
						" seconds."
					]
				}) : null,
				error && !locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm text-danger",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					disabled: busy || locked,
					children: busy ? "Checking password…" : "Sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "This can take a moment. The password is stretched on purpose."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-6 min-h-11 text-sm text-muted underline decoration-line underline-offset-4",
			onClick: () => {
				setPhrase("");
				setEraseOpen(true);
			},
			children: "Forgot the password? Erase this browser vault"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: eraseOpen,
			onOpenChange: setEraseOpen,
			title: "Erase this vault?",
			description: "This deletes the administrator and every database stored in this browser. It cannot be undone.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Type ERASE to confirm",
				htmlFor: "erase-phrase",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "erase-phrase",
					value: phrase,
					onChange: (event) => setPhrase(event.target.value),
					autoComplete: "off"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setEraseOpen(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					disabled: phrase !== "ERASE",
					onClick: () => {
						erase();
						setEraseOpen(false);
						toast("Vault erased from this browser.");
					},
					children: "Erase vault"
				})]
			})]
		})
	] });
}
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-paper px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium tracking-widest text-muted",
					children: "HARIS PRO"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl text-ink",
					children: "Secure Database Builder"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "Opening your workspace…"
				})
			]
		})
	});
}
function SecurityScreen() {
	const activity = useVault((state) => state.vault.activity);
	const busy = useVault((state) => state.busy);
	const changePassword = useVault((state) => state.changePassword);
	const [current, setCurrent] = (0, import_react.useState)("");
	const [next, setNext] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		if (next.length < 10 || next !== confirm) {
			setError("Current password must be correct, and the new password needs at least 10 matching characters.");
			return;
		}
		try {
			await changePassword(current, next);
			setCurrent("");
			setNext("");
			setConfirm("");
			toast("Password updated.");
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not update password.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,22rem)_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Security"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Your password stretches through PBKDF2 and wraps the key that encrypts every database. Changing it does not rewrite the records, only the lock."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 rounded-xl border border-line bg-card p-6",
				onSubmit,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Change administrator password"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Current password",
							htmlFor: "current-password",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
								id: "current-password",
								autoComplete: "current-password",
								value: current,
								onChange: (event) => setCurrent(event.target.value),
								disabled: busy
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "New password",
							htmlFor: "next-password",
							hint: "At least 10 characters.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
								id: "next-password",
								autoComplete: "new-password",
								value: next,
								onChange: (event) => setNext(event.target.value),
								disabled: busy
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Confirm new password",
							htmlFor: "confirm-next",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
								id: "confirm-next",
								autoComplete: "new-password",
								value: confirm,
								onChange: (event) => setConfirm(event.target.value),
								disabled: busy
							})
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 text-sm text-danger",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy,
							children: busy ? "Updating…" : "Update password"
						})
					]
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Recent activity"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Newest first. Failed attempts are written on the next successful sign-in."
			}),
			activity.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "No events yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 divide-y divide-line rounded-lg border border-line bg-card",
				children: activity.slice(0, 100).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col gap-1 px-4 py-3 sm:flex-row sm:items-baseline sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: item.event
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
						className: "text-sm text-muted tabular-nums",
						dateTime: new Date(item.at).toISOString(),
						children: format(item.at, "yyyy-MM-dd HH:mm")
					})]
				}, item.id))
			})
		] })]
	});
}
function sectionOf(screen) {
	if (screen.name === "settings") return "settings";
	if (screen.name === "backup") return "backup";
	return "workspace";
}
function Shell({ children }) {
	const screen = useVault((state) => state.screen);
	const username = useVault((state) => state.account?.username ?? "");
	const go = useVault((state) => state.go);
	const lock = useVault((state) => state.lock);
	const section = sectionOf(screen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-5xl flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 px-1 font-display text-xl",
						onClick: () => go({ name: "home" }),
						children: "Haris"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-wrap items-center gap-1",
						"aria-label": "Workspace",
						children: [
							{
								id: "workspace",
								label: "Workspace",
								icon: Database,
								screen: { name: "home" }
							},
							{
								id: "settings",
								label: "Security",
								icon: Shield,
								screen: { name: "settings" }
							},
							{
								id: "backup",
								label: "Backup",
								icon: Archive,
								screen: { name: "backup" }
							}
						].map((item) => {
							const Icon = item.icon;
							const current = section === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-current": current ? "page" : void 0,
								onClick: () => go(item.screen),
								className: cn("inline-flex min-h-11 items-center gap-2 rounded-md px-3 text-sm font-medium", current ? "bg-ink text-paper" : "text-muted hover:bg-ink/5 hover:text-ink"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									"aria-hidden": "true"
								}), item.label]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-sm text-muted sm:inline",
							children: username
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: lock,
							className: "inline-flex min-h-11 items-center gap-2 rounded-md px-3 text-sm font-medium text-ink hover:bg-ink/5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Log out"]
						})]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto w-full max-w-5xl px-4 py-6",
			children
		})]
	});
}
function BackLink({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "mb-4 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-muted hover:text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
			className: "size-4",
			"aria-hidden": "true"
		}), label]
	});
}
function useConfirm() {
	const [pending, setPending] = (0, import_react.useState)(null);
	const [working, setWorking] = (0, import_react.useState)(false);
	async function confirm() {
		if (!pending) return;
		setWorking(true);
		try {
			await pending.run();
			setPending(null);
		} catch (error) {
			toast(error instanceof Error ? error.message : "Could not complete that.");
		} finally {
			setWorking(false);
		}
	}
	return {
		pending,
		setPending,
		working,
		confirm
	};
}
function HomeScreen() {
	const vault = useVault((state) => state.vault);
	const go = useVault((state) => state.go);
	const createDatabase = useVault((state) => state.createDatabase);
	const deleteDatabase = useVault((state) => state.deleteDatabase);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const dialog = useConfirm();
	async function onCreate(event) {
		event.preventDefault();
		setError("");
		setSaving(true);
		try {
			const id = await createDatabase(name, description);
			setOpen(false);
			setName("");
			setDescription("");
			toast("Database created.");
			go({
				name: "database",
				id
			});
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not create database.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Workspace"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: "Offline databases, sealed with your password."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => {
					setError("");
					setOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "size-4",
					"aria-hidden": "true"
				}), "New database"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "mb-6 grid grid-cols-3 gap-3",
			children: [
				["Databases", vault.databases.length],
				["Tables", countTables(vault)],
				["Records", countRows(vault)]
			].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-line bg-card px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-sm text-muted",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "font-display text-2xl tabular-nums",
					children: value
				})]
			}, String(label)))
		}),
		vault.databases.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-dashed border-line bg-card px-6 py-12 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, {
					className: "mx-auto size-8 text-ink",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 font-display text-2xl",
					children: "No databases yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-2 max-w-md text-muted",
					children: "Create one to start adding tables and records. Everything stays encrypted in this browser."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6",
					onClick: () => setOpen(true),
					children: "Create database"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-3 sm:grid-cols-2",
			children: vault.databases.map((database) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-lg border border-line bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "w-full text-left",
					onClick: () => go({
						name: "database",
						id: database.id
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: database.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 min-h-5 text-sm text-muted",
							children: database.description || "No description"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted tabular-nums",
							children: [
								database.tables.length,
								" tables · ",
								countRowsIn(database),
								" records"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => dialog.setPending({
							title: "Delete database?",
							body: `${database.name} and every table inside it will be removed. This cannot be undone.`,
							confirmLabel: "Delete database",
							run: async () => {
								await deleteDatabase(database.id);
								toast("Database deleted.");
							}
						}),
						children: "Delete"
					})
				})]
			}, database.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			onOpenChange: setOpen,
			title: "Create database",
			description: "Name it, then add tables inside.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onCreate,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Database name",
						htmlFor: "db-name",
						error,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "db-name",
							value: name,
							onChange: (event) => setName(event.target.value),
							autoFocus: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Description (optional)",
						htmlFor: "db-description",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "db-description",
							value: description,
							onChange: (event) => setDescription(event.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => setOpen(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: saving,
							children: saving ? "Creating…" : "Create"
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: dialog.pending !== null,
			title: dialog.pending?.title ?? "",
			body: dialog.pending?.body ?? "",
			confirmLabel: dialog.pending?.confirmLabel ?? "Delete",
			destructive: true,
			pending: dialog.working,
			onConfirm: () => void dialog.confirm(),
			onOpenChange: (next) => {
				if (!next) dialog.setPending(null);
			}
		})
	] });
}
function DatabaseScreen({ id }) {
	const vault = useVault((state) => state.vault);
	const go = useVault((state) => state.go);
	const createTable = useVault((state) => state.createTable);
	const deleteTable = useVault((state) => state.deleteTable);
	const deleteDatabase = useVault((state) => state.deleteDatabase);
	const database = vault.databases.find((item) => item.id === id);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [tableName, setTableName] = (0, import_react.useState)("");
	const [columns, setColumns] = (0, import_react.useState)([{
		key: "value",
		name: "value",
		type: "text"
	}]);
	const [error, setError] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const dialog = useConfirm();
	if (!database) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
			label: "Workspace",
			onClick: () => go({ name: "home" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Database missing"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: "That database is no longer in this workspace."
		})
	] });
	async function onCreate(event) {
		event.preventDefault();
		setSaving(true);
		setError("");
		try {
			const tableId = await createTable(id, tableName, columns.map((column) => ({
				name: column.name,
				type: column.type
			})));
			setOpen(false);
			setTableName("");
			setColumns([{
				key: crypto.randomUUID(),
				name: "value",
				type: "text"
			}]);
			toast("Table created.");
			go({
				name: "records",
				databaseId: id,
				tableId
			});
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not create table.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
			label: "Workspace",
			onClick: () => go({ name: "home" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: database.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: database.description || "No description"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => {
					setError("");
					setOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "size-4",
					"aria-hidden": "true"
				}), "New table"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 font-display text-xl",
			children: "Tables"
		}),
		database.tables.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-dashed border-line bg-card px-6 py-12 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table2, {
					className: "mx-auto size-8",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-4 font-display text-2xl",
					children: "No tables yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-2 max-w-md text-muted",
					children: "A table is a named set of columns. Records you add later fill those columns."
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-3",
			children: database.tables.map((table) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-lg border border-line bg-card p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl",
							children: table.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: table.columns.map((column) => `${column.name} · ${COLUMN_LABEL[column.type]}`).join("   ")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted tabular-nums",
							children: [table.rows.length, " records"]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => go({
								name: "records",
								databaseId: id,
								tableId: table.id
							}),
							children: "Open records"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => dialog.setPending({
								title: "Delete table?",
								body: `${table.name} and its records will be removed. This cannot be undone.`,
								confirmLabel: "Delete table",
								run: async () => {
									await deleteTable(id, table.id);
									toast("Table deleted.");
								}
							}),
							children: "Delete"
						})]
					})]
				})
			}, table.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => dialog.setPending({
					title: "Delete database?",
					body: `${database.name} and every table inside it will be removed.`,
					confirmLabel: "Delete database",
					run: async () => {
						await deleteDatabase(database.id);
						go({ name: "home" });
						toast("Database deleted.");
					}
				}),
				children: "Delete database"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			onOpenChange: setOpen,
			title: "New table",
			description: "Columns are fixed after the table is created.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onCreate,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Table name",
						htmlFor: "table-name",
						hint: "Start with a letter. Then letters, numbers, or underscore.",
						error,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "table-name",
							value: tableName,
							spellCheck: false,
							onChange: (event) => setTableName(event.target.value),
							autoFocus: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 grid gap-3",
						children: columns.map((column, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-[1fr_9rem_auto] sm:items-end",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: index === 0 ? "Column" : "Column",
									htmlFor: `col-${column.key}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: `col-${column.key}`,
										value: column.name,
										spellCheck: false,
										onChange: (event) => setColumns((current) => current.map((item) => item.key === column.key ? {
											...item,
											name: event.target.value
										} : item))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mb-4 block text-sm font-medium text-ink",
									children: ["Type", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: `${controlClass} mt-1.5`,
										value: column.type,
										onChange: (event) => setColumns((current) => current.map((item) => item.key === column.key ? {
											...item,
											type: event.target.value
										} : item)),
										children: Object.keys(COLUMN_LABEL).map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: type,
											children: COLUMN_LABEL[type]
										}, type))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									className: "mb-4",
									disabled: columns.length === 1,
									onClick: () => setColumns((current) => current.filter((item) => item.key !== column.key)),
									children: "Remove"
								})
							]
						}, column.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						disabled: columns.length >= 12,
						onClick: () => setColumns((current) => [...current, {
							key: crypto.randomUUID(),
							name: "",
							type: "text"
						}]),
						children: "Add column"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => setOpen(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: saving,
							children: saving ? "Creating…" : "Create table"
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: dialog.pending !== null,
			title: dialog.pending?.title ?? "",
			body: dialog.pending?.body ?? "",
			confirmLabel: dialog.pending?.confirmLabel ?? "Delete",
			destructive: true,
			pending: dialog.working,
			onConfirm: () => void dialog.confirm(),
			onOpenChange: (next) => {
				if (!next) dialog.setPending(null);
			}
		})
	] });
}
function draftFromRow(columns, row) {
	const draft = {};
	for (const column of columns) {
		const value = row?.values[column.id];
		if (column.type === "boolean") draft[column.id] = value === true ? "true" : "false";
		else if (value === null || value === void 0) draft[column.id] = "";
		else draft[column.id] = String(value);
	}
	return draft;
}
function parseDraft(columns, draft) {
	const values = {};
	for (const column of columns) {
		const raw = draft[column.id] ?? "";
		if (column.type === "text") {
			if (raw.length > 1e4) return { error: `${column.name} is too long.` };
			values[column.id] = raw;
		} else if (column.type === "number") {
			if (!raw.trim()) values[column.id] = null;
			else {
				const parsed = Number(raw);
				if (!Number.isFinite(parsed)) return { error: `${column.name} must be a number.` };
				values[column.id] = parsed;
			}
		} else if (column.type === "date") {
			if (!raw) values[column.id] = null;
			else if (!DATE_RE.test(raw)) return { error: `${column.name} needs a real date.` };
			else values[column.id] = raw;
		} else values[column.id] = raw === "true";
	}
	return { values };
}
function RecordsScreen({ databaseId, tableId }) {
	const vault = useVault((state) => state.vault);
	const go = useVault((state) => state.go);
	const saveRow = useVault((state) => state.saveRow);
	const deleteRow = useVault((state) => state.deleteRow);
	const database = vault.databases.find((item) => item.id === databaseId);
	const table = database?.tables.find((item) => item.id === tableId);
	const [query, setQuery] = (0, import_react.useState)("");
	const [editor, setEditor] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const dialog = useConfirm();
	const rows = (0, import_react.useMemo)(() => {
		if (!table) return [];
		const needle = query.trim().toLowerCase();
		return [...needle ? table.rows.filter((row) => table.columns.some((column) => formatCell(row.values[column.id] ?? null, column.type).toLowerCase().includes(needle))) : table.rows].sort((a, b) => b.createdAt - a.createdAt).slice(0, 500);
	}, [query, table]);
	if (!database || !table) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
			label: "Workspace",
			onClick: () => go({ name: "home" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Table missing"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-muted",
			children: "That table is no longer in this workspace."
		})
	] });
	function openEditor(row) {
		setError("");
		setEditor({
			row,
			draft: draftFromRow(table.columns, row)
		});
	}
	async function onSave(event) {
		event.preventDefault();
		if (!editor || !table) return;
		const parsed = parseDraft(table.columns, editor.draft);
		if ("error" in parsed) {
			setError(parsed.error);
			return;
		}
		setSaving(true);
		try {
			await saveRow(databaseId, tableId, editor.row?.id ?? null, parsed.values);
			setEditor(null);
			toast(editor.row ? "Record updated." : "Record saved.");
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not save record.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
			label: database.name,
			onClick: () => go({
				name: "database",
				id: databaseId
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: table.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted tabular-nums",
				children: [
					table.rows.length,
					" records in ",
					database.name
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => openEditor(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "size-4",
					"aria-hidden": "true"
				}), "Add record"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mb-4 max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Search records",
				"aria-label": "Search records",
				className: "pl-10"
			})]
		}),
		table.rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-dashed border-line bg-card px-6 py-12 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "No records yet"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Add the first row for this table."
			})]
		}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "No records match that search."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 md:hidden",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-line bg-card p-4",
					children: [
						table.columns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3 py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: column.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right text-sm break-words",
								children: formatCell(row.values[column.id] ?? null, column.type)
							})]
						}, column.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted tabular-nums",
							children: format(row.createdAt, "yyyy-MM-dd HH:mm")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => openEditor(row),
								children: "Edit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => dialog.setPending({
									title: "Delete record?",
									body: "This cannot be undone.",
									confirmLabel: "Delete record",
									run: async () => {
										await deleteRow(databaseId, tableId, row.id);
										toast("Record deleted.");
									}
								}),
								children: "Delete"
							})]
						})
					]
				}, row.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto rounded-lg border border-line bg-card md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line text-sm text-muted",
						children: [
							table.columns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: column.name
							}, column.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Created"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Actions"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-line last:border-b-0",
						children: [
							table.columns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "max-w-64 px-3 py-3 align-top text-sm break-words",
								children: formatCell(row.values[column.id] ?? null, column.type)
							}, column.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-3 align-top text-sm text-muted tabular-nums whitespace-nowrap",
								children: format(row.createdAt, "yyyy-MM-dd HH:mm")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-3 align-top",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "secondary",
										onClick: () => openEditor(row),
										children: "Edit"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "secondary",
										onClick: () => dialog.setPending({
											title: "Delete record?",
											body: "This cannot be undone.",
											confirmLabel: "Delete record",
											run: async () => {
												await deleteRow(databaseId, tableId, row.id);
												toast("Record deleted.");
											}
										}),
										children: "Delete"
									})]
								})
							})
						]
					}, row.id)) })]
				})
			}),
			table.rows.length > 500 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Showing the 500 newest matches."
			}) : null
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open: editor !== null,
			onOpenChange: (next) => {
				if (!next) setEditor(null);
			},
			title: editor?.row ? "Edit record" : "Add record",
			children: editor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onSave,
				children: [
					table.columns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: column.name,
						htmlFor: `field-${column.id}`,
						children: column.type === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: `field-${column.id}`,
								type: "checkbox",
								className: "size-5 accent-ink",
								checked: editor.draft[column.id] === "true",
								onChange: (event) => setEditor((current) => current ? {
									...current,
									draft: {
										...current.draft,
										[column.id]: event.target.checked ? "true" : "false"
									}
								} : current)
							}), "Yes"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `field-${column.id}`,
							type: column.type === "number" ? "number" : column.type === "date" ? "date" : "text",
							inputMode: column.type === "number" ? "decimal" : void 0,
							value: editor.draft[column.id] ?? "",
							onChange: (event) => setEditor((current) => current ? {
								...current,
								draft: {
									...current.draft,
									[column.id]: event.target.value
								}
							} : current),
							onWheel: column.type === "number" ? (event) => event.currentTarget.blur() : void 0
						})
					}, column.id)),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-sm text-danger",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => setEditor(null),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: saving,
							children: saving ? "Saving…" : "Save"
						})]
					})
				]
			}) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: dialog.pending !== null,
			title: dialog.pending?.title ?? "",
			body: dialog.pending?.body ?? "",
			confirmLabel: dialog.pending?.confirmLabel ?? "Delete",
			destructive: true,
			pending: dialog.working,
			onConfirm: () => void dialog.confirm(),
			onOpenChange: (next) => {
				if (!next) dialog.setPending(null);
			}
		})
	] });
}
function Home() {
	const status = useVault((state) => state.status);
	const screen = useVault((state) => state.screen);
	const hydrate = useVault((state) => state.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	let body;
	if (status === "booting") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	else if (status === "setup") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupScreen, {});
	else if (status === "locked") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {});
	else body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		screen.name === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {}),
		screen.name === "database" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseScreen, { id: screen.id }),
		screen.name === "records" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordsScreen, {
			databaseId: screen.databaseId,
			tableId: screen.tableId
		}),
		screen.name === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecurityScreen, {}),
		screen.name === "backup" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupScreen, {})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [body, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		position: "top-center",
		toastOptions: { style: {
			background: "var(--color-card)",
			color: "var(--color-ink)",
			border: "1px solid var(--color-line)"
		} }
	})] });
}
//#endregion
export { Home as component };
