import { useState, type FormEvent } from "react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, PasswordInput } from "@/components/ui/field";
import { useVault } from "@/lib/vault-store";

export function SecurityScreen() {
  const activity = useVault((state) => state.vault.activity);
  const busy = useVault((state) => state.busy);
  const changePassword = useVault((state) => state.changePassword);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (next.length < 10 || next !== confirm) {
      setError("Current password must be correct, and the new password needs at least 10 matching characters.");
      return;
    }
    try {
      await changePassword(current, next);
      setCurrent("");
      setNext("");
      setConfirm("");
      toast("Password updated.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not update password.");
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,22rem)_1fr]">
      <section>
        <h1 className="font-display text-3xl">Security</h1>
        <p className="mt-2 text-sm text-muted">
          Your password stretches through PBKDF2 and wraps the key that encrypts every database. Changing it
          does not rewrite the records, only the lock.
        </p>
        <form className="mt-6 rounded-xl border border-line bg-card p-6" onSubmit={onSubmit}>
          <h2 className="font-display text-xl">Change administrator password</h2>
          <div className="mt-4">
            <Field label="Current password" htmlFor="current-password">
              <PasswordInput
                id="current-password"
                autoComplete="current-password"
                value={current}
                onChange={(event) => setCurrent(event.target.value)}
                disabled={busy}
              />
            </Field>
            <Field label="New password" htmlFor="next-password" hint="At least 10 characters.">
              <PasswordInput
                id="next-password"
                autoComplete="new-password"
                value={next}
                onChange={(event) => setNext(event.target.value)}
                disabled={busy}
              />
            </Field>
            <Field label="Confirm new password" htmlFor="confirm-next">
              <PasswordInput
                id="confirm-next"
                autoComplete="new-password"
                value={confirm}
                onChange={(event) => setConfirm(event.target.value)}
                disabled={busy}
              />
            </Field>
            {error ? (
              <p className="mb-4 text-sm text-danger" role="alert">
                {error}
              </p>
            ) : null}
            <Button type="submit" disabled={busy}>
              {busy ? "Updating…" : "Update password"}
            </Button>
          </div>
        </form>
      </section>
      <section>
        <h2 className="font-display text-xl">Recent activity</h2>
        <p className="mt-1 text-sm text-muted">Newest first. Failed attempts are written on the next successful sign-in.</p>
        {activity.length === 0 ? (
          <p className="mt-4 text-muted">No events yet.</p>
        ) : (
          <ul className="mt-4 divide-y divide-line rounded-lg border border-line bg-card">
            {activity.slice(0, 100).map((item) => (
              <li key={item.id} className="flex flex-col gap-1 px-4 py-3 sm:flex-row sm:items-baseline sm:justify-between">
                <span className="text-sm">{item.event}</span>
                <time className="text-sm text-muted tabular-nums" dateTime={new Date(item.at).toISOString()}>
                  {format(item.at, "yyyy-MM-dd HH:mm")}
                </time>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
