import { useMemo, useState, type FormEvent } from "react";
import { format } from "date-fns";
import { Database, Plus, Search, Table2 } from "lucide-react";
import { toast } from "sonner";
import { BackLink } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { controlClass, Field, Input } from "@/components/ui/field";
import { ConfirmDialog, Modal } from "@/components/ui/modal";
import { useVault } from "@/lib/vault-store";
import {
  COLUMN_LABEL,
  DATE_RE,
  countRows,
  countRowsIn,
  countTables,
  formatCell,
  type Cell,
  type Column,
  type ColumnType,
  type Row,
} from "@/lib/vault-types";

function useConfirm() {
  const [pending, setPending] = useState<{
    title: string;
    body: string;
    confirmLabel: string;
    run: () => Promise<void>;
  } | null>(null);
  const [working, setWorking] = useState(false);

  async function confirm() {
    if (!pending) return;
    setWorking(true);
    try {
      await pending.run();
      setPending(null);
    } catch (error) {
      toast(error instanceof Error ? error.message : "Could not complete that.");
    } finally {
      setWorking(false);
    }
  }

  return { pending, setPending, working, confirm };
}

export function HomeScreen() {
  const vault = useVault((state) => state.vault);
  const go = useVault((state) => state.go);
  const createDatabase = useVault((state) => state.createDatabase);
  const deleteDatabase = useVault((state) => state.deleteDatabase);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const dialog = useConfirm();

  async function onCreate(event: FormEvent) {
    event.preventDefault();
    setError("");
    setSaving(true);
    try {
      const id = await createDatabase(name, description);
      setOpen(false);
      setName("");
      setDescription("");
      toast("Database created.");
      go({ name: "database", id });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not create database.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Workspace</h1>
          <p className="mt-1 text-muted">Offline databases, sealed with your password.</p>
        </div>
        <Button
          onClick={() => {
            setError("");
            setOpen(true);
          }}
        >
          <Plus className="size-4" aria-hidden="true" />
          New database
        </Button>
      </div>

      <dl className="mb-6 grid grid-cols-3 gap-3">
        {[
          ["Databases", vault.databases.length],
          ["Tables", countTables(vault)],
          ["Records", countRows(vault)],
        ].map(([label, value]) => (
          <div key={String(label)} className="rounded-lg border border-line bg-card px-4 py-3">
            <dt className="text-sm text-muted">{label}</dt>
            <dd className="font-display text-2xl tabular-nums">{value}</dd>
          </div>
        ))}
      </dl>

      {vault.databases.length === 0 ? (
        <div className="rounded-xl border border-dashed border-line bg-card px-6 py-12 text-center">
          <Database className="mx-auto size-8 text-ink" aria-hidden="true" />
          <h2 className="mt-4 font-display text-2xl">No databases yet</h2>
          <p className="mx-auto mt-2 max-w-md text-muted">
            Create one to start adding tables and records. Everything stays encrypted in this browser.
          </p>
          <Button className="mt-6" onClick={() => setOpen(true)}>
            Create database
          </Button>
        </div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {vault.databases.map((database) => (
            <li key={database.id} className="rounded-lg border border-line bg-card p-4">
              <button type="button" className="w-full text-left" onClick={() => go({ name: "database", id: database.id })}>
                <h2 className="font-display text-xl">{database.name}</h2>
                <p className="mt-1 min-h-5 text-sm text-muted">{database.description || "No description"}</p>
                <p className="mt-3 text-sm text-muted tabular-nums">
                  {database.tables.length} tables · {countRowsIn(database)} records
                </p>
              </button>
              <div className="mt-3">
                <Button
                  variant="secondary"
                  onClick={() =>
                    dialog.setPending({
                      title: "Delete database?",
                      body: `${database.name} and every table inside it will be removed. This cannot be undone.`,
                      confirmLabel: "Delete database",
                      run: async () => {
                        await deleteDatabase(database.id);
                        toast("Database deleted.");
                      },
                    })
                  }
                >
                  Delete
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Modal open={open} onOpenChange={setOpen} title="Create database" description="Name it, then add tables inside.">
        <form onSubmit={onCreate}>
          <Field label="Database name" htmlFor="db-name" error={error}>
            <Input id="db-name" value={name} onChange={(event) => setName(event.target.value)} autoFocus />
          </Field>
          <Field label="Description (optional)" htmlFor="db-description">
            <Input
              id="db-description"
              value={description}
              onChange={(event) => setDescription(event.target.value)}
            />
          </Field>
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Creating…" : "Create"}
            </Button>
          </div>
        </form>
      </Modal>
      <ConfirmDialog
        open={dialog.pending !== null}
        title={dialog.pending?.title ?? ""}
        body={dialog.pending?.body ?? ""}
        confirmLabel={dialog.pending?.confirmLabel ?? "Delete"}
        destructive
        pending={dialog.working}
        onConfirm={() => void dialog.confirm()}
        onOpenChange={(next) => {
          if (!next) dialog.setPending(null);
        }}
      />
    </div>
  );
}

export function DatabaseScreen({ id }: { id: string }) {
  const vault = useVault((state) => state.vault);
  const go = useVault((state) => state.go);
  const createTable = useVault((state) => state.createTable);
  const deleteTable = useVault((state) => state.deleteTable);
  const deleteDatabase = useVault((state) => state.deleteDatabase);
  const database = vault.databases.find((item) => item.id === id);
  const [open, setOpen] = useState(false);
  const [tableName, setTableName] = useState("");
  const [columns, setColumns] = useState<{ key: string; name: string; type: ColumnType }[]>([
    { key: "value", name: "value", type: "text" },
  ]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const dialog = useConfirm();

  if (!database) {
    return (
      <div>
        <BackLink label="Workspace" onClick={() => go({ name: "home" })} />
        <h1 className="font-display text-3xl">Database missing</h1>
        <p className="mt-2 text-muted">That database is no longer in this workspace.</p>
      </div>
    );
  }

  async function onCreate(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      const tableId = await createTable(
        id,
        tableName,
        columns.map((column) => ({ name: column.name, type: column.type })),
      );
      setOpen(false);
      setTableName("");
      setColumns([{ key: crypto.randomUUID(), name: "value", type: "text" }]);
      toast("Table created.");
      go({ name: "records", databaseId: id, tableId });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not create table.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <BackLink label="Workspace" onClick={() => go({ name: "home" })} />
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">{database.name}</h1>
          <p className="mt-1 text-muted">{database.description || "No description"}</p>
        </div>
        <Button
          onClick={() => {
            setError("");
            setOpen(true);
          }}
        >
          <Plus className="size-4" aria-hidden="true" />
          New table
        </Button>
      </div>

      <h2 className="mb-3 font-display text-xl">Tables</h2>
      {database.tables.length === 0 ? (
        <div className="rounded-xl border border-dashed border-line bg-card px-6 py-12 text-center">
          <Table2 className="mx-auto size-8" aria-hidden="true" />
          <h3 className="mt-4 font-display text-2xl">No tables yet</h3>
          <p className="mx-auto mt-2 max-w-md text-muted">
            A table is a named set of columns. Records you add later fill those columns.
          </p>
        </div>
      ) : (
        <ul className="grid gap-3">
          {database.tables.map((table) => (
            <li key={table.id} className="rounded-lg border border-line bg-card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-xl">{table.name}</h3>
                  <p className="mt-1 text-sm text-muted">
                    {table.columns.map((column) => `${column.name} (${COLUMN_LABEL[column.type]})`).join(" · ")}
                  </p>
                  <p className="mt-2 text-sm text-muted tabular-nums">{table.rows.length} records</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => go({ name: "records", databaseId: id, tableId: table.id })}>
                    Open records
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() =>
                      dialog.setPending({
                        title: "Delete table?",
                        body: `${table.name} and its records will be removed. This cannot be undone.`,
                        confirmLabel: "Delete table",
                        run: async () => {
                          await deleteTable(id, table.id);
                          toast("Table deleted.");
                        },
                      })
                    }
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      <div className="mt-8">
        <Button
          variant="secondary"
          onClick={() =>
            dialog.setPending({
              title: "Delete database?",
              body: `${database.name} and every table inside it will be removed.`,
              confirmLabel: "Delete database",
              run: async () => {
                await deleteDatabase(database.id);
                go({ name: "home" });
                toast("Database deleted.");
              },
            })
          }
        >
          Delete database
        </Button>
      </div>

      <Modal
        open={open}
        onOpenChange={setOpen}
        title="New table"
        description="Columns are fixed after the table is created."
      >
        <form onSubmit={onCreate}>
          <Field
            label="Table name"
            htmlFor="table-name"
            hint="Start with a letter. Then letters, numbers, or underscore."
            error={error}
          >
            <Input
              id="table-name"
              value={tableName}
              spellCheck={false}
              onChange={(event) => setTableName(event.target.value)}
              autoFocus
            />
          </Field>
          <div className="mb-2 grid gap-4">
            {columns.map((column, index) => (
              <div key={column.key} className="border-t border-line pt-4">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <p className="text-sm font-medium">Column {index + 1}</p>
                  <Button
                    variant="ghost"
                    className="px-2"
                    disabled={columns.length === 1}
                    onClick={() => setColumns((current) => current.filter((item) => item.key !== column.key))}
                  >
                    Remove
                  </Button>
                </div>
                <Field label="Name" htmlFor={`col-${column.key}`}>
                  <Input
                    id={`col-${column.key}`}
                    value={column.name}
                    spellCheck={false}
                    onChange={(event) =>
                      setColumns((current) =>
                        current.map((item) => (item.key === column.key ? { ...item, name: event.target.value } : item)),
                      )
                    }
                  />
                </Field>
                <label className="mb-1.5 block text-sm font-medium" htmlFor={`type-${column.key}`}>
                  Type
                </label>
                <select
                  id={`type-${column.key}`}
                  className={controlClass}
                  value={column.type}
                  onChange={(event) =>
                    setColumns((current) =>
                      current.map((item) =>
                        item.key === column.key ? { ...item, type: event.target.value as ColumnType } : item,
                      ),
                    )
                  }
                >
                  {(Object.keys(COLUMN_LABEL) as ColumnType[]).map((type) => (
                    <option key={type} value={type}>
                      {COLUMN_LABEL[type]}
                    </option>
                  ))}
                </select>
              </div>
            ))}
          </div>
          <Button
            variant="secondary"
            disabled={columns.length >= 12}
            onClick={() =>
              setColumns((current) => [...current, { key: crypto.randomUUID(), name: "", type: "text" }])
            }
          >
            Add column
          </Button>
          <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Creating…" : "Create table"}
            </Button>
          </div>
        </form>
      </Modal>
      <ConfirmDialog
        open={dialog.pending !== null}
        title={dialog.pending?.title ?? ""}
        body={dialog.pending?.body ?? ""}
        confirmLabel={dialog.pending?.confirmLabel ?? "Delete"}
        destructive
        pending={dialog.working}
        onConfirm={() => void dialog.confirm()}
        onOpenChange={(next) => {
          if (!next) dialog.setPending(null);
        }}
      />
    </div>
  );
}

function draftFromRow(columns: Column[], row: Row | null): Record<string, string> {
  const draft: Record<string, string> = {};
  for (const column of columns) {
    const value = row?.values[column.id];
    if (column.type === "boolean") {
      draft[column.id] = value === true ? "true" : "false";
    } else if (value === null || value === undefined) {
      draft[column.id] = "";
    } else {
      draft[column.id] = String(value);
    }
  }
  return draft;
}

function parseDraft(columns: Column[], draft: Record<string, string>): { values: Record<string, Cell> } | { error: string } {
  const values: Record<string, Cell> = {};
  for (const column of columns) {
    const raw = draft[column.id] ?? "";
    if (column.type === "text") {
      if (raw.length > 10000) return { error: `${column.name} is too long.` };
      values[column.id] = raw;
    } else if (column.type === "number") {
      if (!raw.trim()) {
        values[column.id] = null;
      } else {
        const parsed = Number(raw);
        if (!Number.isFinite(parsed)) return { error: `${column.name} must be a number.` };
        values[column.id] = parsed;
      }
    } else if (column.type === "date") {
      if (!raw) values[column.id] = null;
      else if (!DATE_RE.test(raw)) return { error: `${column.name} needs a real date.` };
      else values[column.id] = raw;
    } else {
      values[column.id] = raw === "true";
    }
  }
  return { values };
}

export function RecordsScreen({ databaseId, tableId }: { databaseId: string; tableId: string }) {
  const vault = useVault((state) => state.vault);
  const go = useVault((state) => state.go);
  const saveRow = useVault((state) => state.saveRow);
  const deleteRow = useVault((state) => state.deleteRow);
  const database = vault.databases.find((item) => item.id === databaseId);
  const table = database?.tables.find((item) => item.id === tableId);
  const [query, setQuery] = useState("");
  const [editor, setEditor] = useState<{ row: Row | null; draft: Record<string, string> } | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const dialog = useConfirm();

  const rows = useMemo(() => {
    if (!table) return [];
    const needle = query.trim().toLowerCase();
    const filtered = needle
      ? table.rows.filter((row) =>
          table.columns.some((column) => formatCell(row.values[column.id] ?? null, column.type).toLowerCase().includes(needle)),
        )
      : table.rows;
    return [...filtered].sort((a, b) => b.createdAt - a.createdAt).slice(0, 500);
  }, [query, table]);

  if (!database || !table) {
    return (
      <div>
        <BackLink label="Workspace" onClick={() => go({ name: "home" })} />
        <h1 className="font-display text-3xl">Table missing</h1>
        <p className="mt-2 text-muted">That table is no longer in this workspace.</p>
      </div>
    );
  }

  function openEditor(row: Row | null) {
    setError("");
    setEditor({ row, draft: draftFromRow(table!.columns, row) });
  }

  async function onSave(event: FormEvent) {
    event.preventDefault();
    if (!editor || !table) return;
    const parsed = parseDraft(table.columns, editor.draft);
    if ("error" in parsed) {
      setError(parsed.error);
      return;
    }
    setSaving(true);
    try {
      await saveRow(databaseId, tableId, editor.row?.id ?? null, parsed.values);
      setEditor(null);
      toast(editor.row ? "Record updated." : "Record saved.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not save record.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <BackLink label={database.name} onClick={() => go({ name: "database", id: databaseId })} />
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">{table.name}</h1>
          <p className="mt-1 text-sm text-muted tabular-nums">
            {table.rows.length} records in {database.name}
          </p>
        </div>
        <Button onClick={() => openEditor(null)}>
          <Plus className="size-4" aria-hidden="true" />
          Add record
        </Button>
      </div>

      <div className="relative mb-4 max-w-md">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" aria-hidden="true" />
        <Input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search records"
          aria-label="Search records"
          className="pl-10"
        />
      </div>

      {table.rows.length === 0 ? (
        <div className="rounded-xl border border-dashed border-line bg-card px-6 py-12 text-center">
          <h2 className="font-display text-2xl">No records yet</h2>
          <p className="mt-2 text-muted">Add the first row for this table.</p>
        </div>
      ) : rows.length === 0 ? (
        <p className="text-muted">No records match that search.</p>
      ) : (
        <>
          <ul className="grid gap-3 md:hidden">
            {rows.map((row) => (
              <li key={row.id} className="rounded-lg border border-line bg-card p-4">
                {table.columns.map((column) => (
                  <div key={column.id} className="flex items-start justify-between gap-3 py-1">
                    <span className="text-sm text-muted">{column.name}</span>
                    <span className="text-right text-sm break-words">{formatCell(row.values[column.id] ?? null, column.type)}</span>
                  </div>
                ))}
                <p className="mt-2 text-sm text-muted tabular-nums">{format(row.createdAt, "yyyy-MM-dd HH:mm")}</p>
                <div className="mt-3 flex gap-2">
                  <Button variant="secondary" onClick={() => openEditor(row)}>
                    Edit
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() =>
                      dialog.setPending({
                        title: "Delete record?",
                        body: "This cannot be undone.",
                        confirmLabel: "Delete record",
                        run: async () => {
                          await deleteRow(databaseId, tableId, row.id);
                          toast("Record deleted.");
                        },
                      })
                    }
                  >
                    Delete
                  </Button>
                </div>
              </li>
            ))}
          </ul>
          <div className="hidden overflow-x-auto rounded-lg border border-line bg-card md:block">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="border-b border-line text-sm text-muted">
                  {table.columns.map((column) => (
                    <th key={column.id} className="px-3 py-3 font-medium">
                      {column.name}
                    </th>
                  ))}
                  <th className="px-3 py-3 font-medium">Created</th>
                  <th className="px-3 py-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.id} className="border-b border-line last:border-b-0">
                    {table.columns.map((column) => (
                      <td key={column.id} className="max-w-64 px-3 py-3 align-top text-sm break-words">
                        {formatCell(row.values[column.id] ?? null, column.type)}
                      </td>
                    ))}
                    <td className="px-3 py-3 align-top text-sm text-muted tabular-nums whitespace-nowrap">
                      {format(row.createdAt, "yyyy-MM-dd HH:mm")}
                    </td>
                    <td className="px-3 py-3 align-top">
                      <div className="flex gap-2">
                        <Button variant="secondary" onClick={() => openEditor(row)}>
                          Edit
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() =>
                            dialog.setPending({
                              title: "Delete record?",
                              body: "This cannot be undone.",
                              confirmLabel: "Delete record",
                              run: async () => {
                                await deleteRow(databaseId, tableId, row.id);
                                toast("Record deleted.");
                              },
                            })
                          }
                        >
                          Delete
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {table.rows.length > 500 ? (
            <p className="mt-3 text-sm text-muted">Showing the 500 newest matches.</p>
          ) : null}
        </>
      )}

      <Modal
        open={editor !== null}
        onOpenChange={(next) => {
          if (!next) setEditor(null);
        }}
        title={editor?.row ? "Edit record" : "Add record"}
      >
        {editor ? (
          <form onSubmit={onSave}>
            {table.columns.map((column) => (
              <Field key={column.id} label={column.name} htmlFor={`field-${column.id}`}>
                {column.type === "boolean" ? (
                  <label className="flex min-h-11 items-center gap-3 text-sm">
                    <input
                      id={`field-${column.id}`}
                      type="checkbox"
                      className="size-5 accent-ink"
                      checked={editor.draft[column.id] === "true"}
                      onChange={(event) =>
                        setEditor((current) =>
                          current
                            ? {
                                ...current,
                                draft: { ...current.draft, [column.id]: event.target.checked ? "true" : "false" },
                              }
                            : current,
                        )
                      }
                    />
                    Yes
                  </label>
                ) : (
                  <Input
                    id={`field-${column.id}`}
                    type={column.type === "number" ? "number" : column.type === "date" ? "date" : "text"}
                    inputMode={column.type === "number" ? "decimal" : undefined}
                    value={editor.draft[column.id] ?? ""}
                    onChange={(event) =>
                      setEditor((current) =>
                        current ? { ...current, draft: { ...current.draft, [column.id]: event.target.value } } : current,
                      )
                    }
                    onWheel={column.type === "number" ? (event) => event.currentTarget.blur() : undefined}
                  />
                )}
              </Field>
            ))}
            {error ? (
              <p className="mb-4 text-sm text-danger" role="alert">
                {error}
              </p>
            ) : null}
            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <Button variant="secondary" onClick={() => setEditor(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : "Save"}
              </Button>
            </div>
          </form>
        ) : null}
      </Modal>
      <ConfirmDialog
        open={dialog.pending !== null}
        title={dialog.pending?.title ?? ""}
        body={dialog.pending?.body ?? ""}
        confirmLabel={dialog.pending?.confirmLabel ?? "Delete"}
        destructive
        pending={dialog.working}
        onConfirm={() => void dialog.confirm()}
        onOpenChange={(next) => {
          if (!next) dialog.setPending(null);
        }}
      />
    </div>
  );
}
