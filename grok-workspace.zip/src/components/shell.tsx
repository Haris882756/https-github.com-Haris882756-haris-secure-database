import type { ReactNode } from "react";
import { ArrowLeft, Archive, Database, LogOut, Shield } from "lucide-react";
import { useVault } from "@/lib/vault-store";
import type { Screen } from "@/lib/vault-types";
import { cn } from "@/lib/cn";

function sectionOf(screen: Screen): "workspace" | "settings" | "backup" {
  if (screen.name === "settings") return "settings";
  if (screen.name === "backup") return "backup";
  return "workspace";
}

export function Shell({ children }: { children: ReactNode }) {
  const screen = useVault((state) => state.screen);
  const username = useVault((state) => state.account?.username ?? "");
  const go = useVault((state) => state.go);
  const lock = useVault((state) => state.lock);
  const section = sectionOf(screen);

  const items: { id: typeof section; label: string; icon: typeof Database; screen: Screen }[] = [
    { id: "workspace", label: "Workspace", icon: Database, screen: { name: "home" } },
    { id: "settings", label: "Security", icon: Shield, screen: { name: "settings" } },
    { id: "backup", label: "Backup", icon: Archive, screen: { name: "backup" } },
  ];

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-20 border-b border-line bg-paper">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-3 gap-y-1 px-4 py-2">
          <button type="button" className="min-h-11 px-1 font-display text-xl" onClick={() => go({ name: "home" })}>
            Haris
          </button>
          <nav className="flex flex-1 flex-wrap items-center gap-1" aria-label="Workspace">
            {items.map((item) => {
              const Icon = item.icon;
              const current = section === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={current ? "page" : undefined}
                  onClick={() => go(item.screen)}
                  className={cn(
                    "inline-flex min-h-11 items-center gap-2 rounded-md px-3 text-sm font-medium",
                    current ? "bg-ink text-paper" : "text-muted hover:bg-ink/5 hover:text-ink",
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  {item.label}
                </button>
              );
            })}
          </nav>
          <div className="flex items-center gap-1">
            <span className="hidden text-sm text-muted sm:inline">{username}</span>
            <button
              type="button"
              onClick={lock}
              className="inline-flex min-h-11 items-center gap-2 rounded-md px-3 text-sm font-medium text-ink hover:bg-ink/5"
            >
              <LogOut className="size-4" aria-hidden="true" />
              Log out
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 py-6">{children}</main>
    </div>
  );
}

export function BackLink({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="mb-4 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-muted hover:text-ink"
    >
      <ArrowLeft className="size-4" aria-hidden="true" />
      {label}
    </button>
  );
}
