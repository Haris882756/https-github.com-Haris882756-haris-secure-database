import { useEffect, useState, type FormEvent } from "react";
import { HardDrive, KeyRound, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, Input, PasswordInput } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { useVault } from "@/lib/vault-store";

function BrandPanel() {
  return (
    <aside className="hidden flex-col justify-between bg-ink px-12 py-14 text-paper lg:flex">
      <div>
        <p className="text-sm font-medium tracking-widest text-paper/70">HARIS PRO</p>
        <h1 className="mt-6 max-w-md font-display text-5xl leading-tight">Secure Database Builder</h1>
        <p className="mt-4 max-w-md text-lg text-paper/80">
          A private workspace for databases you do not want sitting in a spreadsheet.
        </p>
      </div>
      <ul className="grid max-w-md gap-5 text-sm leading-6">
        <li className="flex gap-3">
          <ShieldCheck className="mt-0.5 size-5 shrink-0" aria-hidden="true" />
          Password-sealed with PBKDF2 and AES-GCM. The files themselves are encrypted.
        </li>
        <li className="flex gap-3">
          <HardDrive className="mt-0.5 size-5 shrink-0" aria-hidden="true" />
          Stored only in this browser. Nothing is uploaded.
        </li>
        <li className="flex gap-3">
          <KeyRound className="mt-0.5 size-5 shrink-0" aria-hidden="true" />
          Five wrong attempts pause sign-in for 30 seconds.
        </li>
      </ul>
    </aside>
  );
}

function GateFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen bg-paper lg:grid-cols-2">
      <BrandPanel />
      <main className="flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <div className="mb-6 lg:hidden">
            <p className="text-sm font-medium tracking-widest text-muted">HARIS PRO</p>
            <h1 className="mt-2 font-display text-4xl text-ink">Secure Database Builder</h1>
          </div>
          <section className="rounded-xl border border-line bg-card p-6 shadow-panel">{children}</section>
        </div>
      </main>
    </div>
  );
}

export function SetupScreen() {
  const createAccount = useVault((state) => state.createAccount);
  const busy = useVault((state) => state.busy);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (!username.trim() || password.length < 10 || password !== confirm) {
      setError("Enter a username, use at least 10 password characters, and make both passwords match.");
      return;
    }
    try {
      await createAccount(username, password);
      toast("Account created. Please sign in.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not create the account.");
    }
  }

  return (
    <GateFrame>
      <h2 className="font-display text-3xl text-ink">Create administrator</h2>
      <p className="mt-2 text-sm text-muted">
        First-run setup. Choose your own password. If you forget it, this workspace cannot be recovered.
      </p>
      <form className="mt-6" onSubmit={onSubmit}>
        <Field label="Administrator username" htmlFor="username">
          <Input
            id="username"
            name="username"
            autoComplete="username"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            disabled={busy}
          />
        </Field>
        <Field label="Create strong password" htmlFor="new-password" hint="At least 10 characters.">
          <PasswordInput
            id="new-password"
            name="new-password"
            autoComplete="new-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            disabled={busy}
          />
        </Field>
        <Field label="Confirm password" htmlFor="confirm-password">
          <PasswordInput
            id="confirm-password"
            name="confirm-password"
            autoComplete="new-password"
            value={confirm}
            onChange={(event) => setConfirm(event.target.value)}
            disabled={busy}
          />
        </Field>
        {error ? (
          <p className="mb-4 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}
        <Button type="submit" className="w-full" disabled={busy}>
          {busy ? "Creating account…" : "Create secure account"}
        </Button>
        <p className="mt-3 text-sm text-muted">This can take a moment. The password is stretched on purpose.</p>
      </form>
    </GateFrame>
  );
}

export function LoginScreen() {
  const account = useVault((state) => state.account);
  const busy = useVault((state) => state.busy);
  const lockout = useVault((state) => state.lockout);
  const unlock = useVault((state) => state.unlock);
  const erase = useVault((state) => state.erase);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [now, setNow] = useState(() => Date.now());
  const [eraseOpen, setEraseOpen] = useState(false);
  const [phrase, setPhrase] = useState("");

  const waiting = Math.max(0, lockout.lockedUntil - now);
  const locked = waiting > 0;

  useEffect(() => {
    if (!locked) return;
    const timer = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(timer);
  }, [locked]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    try {
      await unlock(password);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Sign-in failed. Check your details.");
      setPassword("");
    }
  }

  return (
    <GateFrame>
      <h2 className="font-display text-3xl text-ink">Sign in</h2>
      <p className="mt-2 text-sm text-muted">Local sign-in. Works offline. Closing the tab locks the workspace.</p>
      <form className="mt-6" onSubmit={onSubmit}>
        <Field label="Administrator" htmlFor="login-user">
          <Input id="login-user" value={account?.username ?? ""} readOnly />
        </Field>
        <Field label="Password" htmlFor="password">
          <PasswordInput
            id="password"
            name="password"
            autoComplete="current-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            disabled={busy || locked}
          />
        </Field>
        {locked ? (
          <p className="mb-4 text-sm text-danger" role="alert">
            Too many attempts. Try again in {Math.ceil(waiting / 1000)} seconds.
          </p>
        ) : null}
        {error && !locked ? (
          <p className="mb-4 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}
        <Button type="submit" className="w-full" disabled={busy || locked}>
          {busy ? "Checking password…" : "Sign in"}
        </Button>
        <p className="mt-3 text-sm text-muted">This can take a moment. The password is stretched on purpose.</p>
      </form>
      <button
        type="button"
        className="mt-6 min-h-11 text-sm text-muted underline decoration-line underline-offset-4"
        onClick={() => {
          setPhrase("");
          setEraseOpen(true);
        }}
      >
        Forgot the password? Erase this browser vault
      </button>
      <Modal
        open={eraseOpen}
        onOpenChange={setEraseOpen}
        title="Erase this vault?"
        description="This deletes the administrator and every database stored in this browser. It cannot be undone."
      >
        <Field label='Type ERASE to confirm' htmlFor="erase-phrase">
          <Input
            id="erase-phrase"
            value={phrase}
            onChange={(event) => setPhrase(event.target.value)}
            autoComplete="off"
          />
        </Field>
        <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={() => setEraseOpen(false)}>
            Cancel
          </Button>
          <Button
            variant="danger"
            disabled={phrase !== "ERASE"}
            onClick={() => {
              erase();
              setEraseOpen(false);
              toast("Vault erased from this browser.");
            }}
          >
            Erase vault
          </Button>
        </div>
      </Modal>
    </GateFrame>
  );
}

export function BootScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-paper px-6">
      <div className="text-center">
        <p className="text-sm font-medium tracking-widest text-muted">HARIS PRO</p>
        <h1 className="mt-3 font-display text-4xl text-ink">Secure Database Builder</h1>
        <p className="mt-3 text-muted">Opening your workspace…</p>
      </div>
    </div>
  );
}
