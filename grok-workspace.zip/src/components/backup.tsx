import { useRef, useState } from "react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ui/modal";
import { downloadText, readJsonFile } from "@/lib/download";
import { useVault } from "@/lib/vault-store";
import {
  ACCOUNT_KEY,
  SEALED_FORMAT,
  WORKSPACE_FORMAT,
  countRows,
  countTables,
  parseSealedBackup,
  parseWorkspaceExport,
  type Vault,
} from "@/lib/vault-types";

export function BackupScreen() {
  const vault = useVault((state) => state.vault);
  const account = useVault((state) => state.account);
  const replaceWorkspace = useVault((state) => state.replaceWorkspace);
  const restoreSealed = useVault((state) => state.restoreSealed);
  const jsonRef = useRef<HTMLInputElement>(null);
  const sealedRef = useRef<HTMLInputElement>(null);
  const [pendingVault, setPendingVault] = useState<Vault | null>(null);
  const [pendingSealed, setPendingSealed] = useState(false);
  const [sealedAccount, setSealedAccount] = useState<ReturnType<typeof parseSealedBackup> | null>(null);
  const [working, setWorking] = useState(false);

  const stored = typeof window === "undefined" ? "" : (localStorage.getItem(ACCOUNT_KEY) ?? "");
  const kilobytes = Math.max(1, Math.round(stored.length / 1024));

  function exportJson() {
    const payload = {
      format: WORKSPACE_FORMAT,
      version: 1,
      exportedAt: new Date().toISOString(),
      databases: vault.databases,
      activity: vault.activity,
    };
    downloadText(`haris-workspace-${format(new Date(), "yyyy-MM-dd")}.json`, JSON.stringify(payload, null, 2));
    toast("Readable export downloaded.");
  }

  function exportSealed() {
    if (!account) return;
    const payload = { format: SEALED_FORMAT, version: 1, exportedAt: new Date().toISOString(), account };
    downloadText(`haris-sealed-${format(new Date(), "yyyy-MM-dd")}.json`, JSON.stringify(payload));
    toast("Sealed vault downloaded.");
  }

  return (
    <div>
      <h1 className="font-display text-3xl">Backup and restore</h1>
      <p className="mt-2 max-w-2xl text-muted">
        The copy in this browser is encrypted with your password. A sealed file keeps that lock. A readable JSON
        file does not — treat it like a printout.
      </p>
      <p className="mt-3 text-sm text-muted tabular-nums">
        {vault.databases.length} databases · {countTables(vault)} tables · {countRows(vault)} records · about{" "}
        {kilobytes} KB sealed in this browser
      </p>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <section className="rounded-xl border border-line bg-card p-6">
          <h2 className="font-display text-xl">Sealed vault</h2>
          <p className="mt-2 text-sm text-muted">
            Move the encrypted workspace to another browser. Restoring it replaces the account on this browser,
            including the password that sealed the file.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button onClick={exportSealed}>Download sealed vault</Button>
            <Button variant="secondary" onClick={() => sealedRef.current?.click()}>
              Restore sealed vault
            </Button>
          </div>
        </section>
        <section className="rounded-xl border border-line bg-card p-6">
          <h2 className="font-display text-xl">Readable JSON</h2>
          <p className="mt-2 text-sm text-muted">
            Export databases and the activity log as plain JSON. Import replaces the databases inside the current
            account. It does not change your password.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <Button onClick={exportJson}>Download JSON</Button>
            <Button variant="secondary" onClick={() => jsonRef.current?.click()}>
              Import JSON
            </Button>
          </div>
        </section>
      </div>

      <input
        ref={jsonRef}
        type="file"
        accept="application/json,.json"
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (!file) return;
          void readJsonFile(file)
            .then((data) => setPendingVault(parseWorkspaceExport(data)))
            .catch((error: unknown) => toast(error instanceof Error ? error.message : "Could not read that file."));
        }}
      />
      <input
        ref={sealedRef}
        type="file"
        accept="application/json,.json"
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (!file) return;
          void readJsonFile(file)
            .then((data) => {
              setSealedAccount(parseSealedBackup(data));
              setPendingSealed(true);
            })
            .catch((error: unknown) => toast(error instanceof Error ? error.message : "Could not read that file."));
        }}
      />

      <ConfirmDialog
        open={pendingVault !== null}
        title="Replace the workspace?"
        body={
          pendingVault
            ? `This replaces your current databases with ${pendingVault.databases.length} databases, ${countTables(pendingVault)} tables, and ${countRows(pendingVault)} records.`
            : ""
        }
        confirmLabel="Import"
        pending={working}
        onOpenChange={(open) => {
          if (!open) setPendingVault(null);
        }}
        onConfirm={() => {
          if (!pendingVault) return;
          setWorking(true);
          void replaceWorkspace(pendingVault)
            .then(() => {
              toast("Workspace imported.");
              setPendingVault(null);
            })
            .catch((error: unknown) => toast(error instanceof Error ? error.message : "Could not import."))
            .finally(() => setWorking(false));
        }}
      />
      <ConfirmDialog
        open={pendingSealed}
        title="Restore sealed vault?"
        body={`This replaces the administrator on this browser with ${sealedAccount?.username ?? "the backup account"}. You will need that vault's password to sign in.`}
        confirmLabel="Restore"
        destructive
        onOpenChange={(open) => {
          if (!open) {
            setPendingSealed(false);
            setSealedAccount(null);
          }
        }}
        onConfirm={() => {
          if (!sealedAccount) return;
          restoreSealed(sealedAccount);
          setPendingSealed(false);
          setSealedAccount(null);
          toast("Sealed vault restored. Sign in with its password.");
        }}
      />
    </div>
  );
}
