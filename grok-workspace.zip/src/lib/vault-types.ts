export type ColumnType = "text" | "number" | "date" | "boolean";

export type Column = {
  id: string;
  name: string;
  type: ColumnType;
};

export type Cell = string | number | boolean | null;

export type Row = {
  id: string;
  values: Record<string, Cell>;
  createdAt: number;
  updatedAt: number;
};

export type DataTable = {
  id: string;
  name: string;
  columns: Column[];
  rows: Row[];
  createdAt: number;
};

export type Database = {
  id: string;
  name: string;
  description: string;
  tables: DataTable[];
  createdAt: number;
};

export type Activity = {
  id: string;
  event: string;
  at: number;
};

export type Vault = {
  databases: Database[];
  activity: Activity[];
};

export type AccountFile = {
  version: 1;
  username: string;
  passSalt: string;
  passHash: string;
  wrapSalt: string;
  wrapIv: string;
  wrappedKey: string;
  vaultIv: string;
  vault: string;
};

export type Screen =
  | { name: "home" }
  | { name: "database"; id: string }
  | { name: "records"; databaseId: string; tableId: string }
  | { name: "settings" }
  | { name: "backup" };

export type Lockout = {
  failed: number;
  lockedUntil: number;
  sinceUnlock: number;
};

export const IDENT = /^[A-Za-z][A-Za-z0-9_]{0,39}$/;
export const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
export const ACCOUNT_KEY = "haris.account.v1";
export const LOCKOUT_KEY = "haris.lockout.v1";
export const WORKSPACE_FORMAT = "haris-secure-database-builder";
export const SEALED_FORMAT = "haris-sealed-vault";

export const COLUMN_LABEL: Record<ColumnType, string> = {
  text: "Text",
  number: "Number",
  date: "Date",
  boolean: "Yes / No",
};

export function emptyVault(): Vault {
  return { databases: [], activity: [] };
}

export function freshLockout(): Lockout {
  return { failed: 0, lockedUntil: 0, sinceUnlock: 0 };
}

export function byName<T extends { name: string }>(a: T, b: T) {
  return a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
}

export function countTables(vault: Vault) {
  return vault.databases.reduce((n, db) => n + db.tables.length, 0);
}

export function countRows(vault: Vault) {
  return vault.databases.reduce(
    (n, db) => n + db.tables.reduce((m, table) => m + table.rows.length, 0),
    0,
  );
}

export function countRowsIn(db: Database) {
  return db.tables.reduce((n, table) => n + table.rows.length, 0);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isCell(value: unknown): value is Cell {
  return (
    value === null ||
    typeof value === "string" ||
    typeof value === "boolean" ||
    (typeof value === "number" && Number.isFinite(value))
  );
}

export function isAccountFile(value: unknown): value is AccountFile {
  if (!isRecord(value) || value.version !== 1) return false;
  const keys = [
    "username",
    "passSalt",
    "passHash",
    "wrapSalt",
    "wrapIv",
    "wrappedKey",
    "vaultIv",
    "vault",
  ] as const;
  return keys.every((key) => typeof value[key] === "string" && value[key].length > 0);
}

function coerce(column: Column, value: unknown): Cell {
  if (column.type === "text") {
    if (typeof value !== "string") return null;
    return value.slice(0, 10000);
  }
  if (column.type === "number") {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
  }
  if (column.type === "date") {
    return typeof value === "string" && DATE_RE.test(value) ? value : null;
  }
  return typeof value === "boolean" ? value : null;
}

function parseColumn(value: unknown): Column {
  if (!isRecord(value)) throw new Error("This file is not a Haris workspace export.");
  if (typeof value.id !== "string" || value.id.length < 8 || value.id.length > 80) {
    throw new Error("This file is not a Haris workspace export.");
  }
  if (typeof value.name !== "string" || !IDENT.test(value.name)) {
    throw new Error("A column name in that file is not allowed.");
  }
  if (value.type !== "text" && value.type !== "number" && value.type !== "date" && value.type !== "boolean") {
    throw new Error("A column type in that file is not allowed.");
  }
  return { id: value.id, name: value.name, type: value.type };
}

function parseRow(columns: Column[], value: unknown): Row {
  if (!isRecord(value)) throw new Error("This file is not a Haris workspace export.");
  if (typeof value.id !== "string" || value.id.length < 8 || value.id.length > 80) {
    throw new Error("This file is not a Haris workspace export.");
  }
  if (typeof value.createdAt !== "number" || typeof value.updatedAt !== "number") {
    throw new Error("This file is not a Haris workspace export.");
  }
  const rawValues = isRecord(value.values) ? value.values : {};
  const values: Record<string, Cell> = {};
  for (const column of columns) {
    const cell = rawValues[column.id];
    if (cell !== undefined && !isCell(cell)) {
      throw new Error("A record in that file has a value this workspace cannot store.");
    }
    values[column.id] = coerce(column, cell);
  }
  return {
    id: value.id,
    values,
    createdAt: value.createdAt,
    updatedAt: value.updatedAt,
  };
}

function parseTable(value: unknown): DataTable {
  if (!isRecord(value) || !Array.isArray(value.columns) || !Array.isArray(value.rows)) {
    throw new Error("This file is not a Haris workspace export.");
  }
  if (typeof value.id !== "string" || typeof value.name !== "string" || typeof value.createdAt !== "number") {
    throw new Error("This file is not a Haris workspace export.");
  }
  if (!IDENT.test(value.name)) throw new Error("A table name in that file is not allowed.");
  if (value.columns.length < 1 || value.columns.length > 12) {
    throw new Error("Each table needs between 1 and 12 columns.");
  }
  if (value.rows.length > 2000) throw new Error("A table in that file has too many records.");
  const columns = value.columns.map(parseColumn);
  const seen = new Set<string>();
  for (const column of columns) {
    const key = column.name.toLowerCase();
    if (seen.has(key)) throw new Error("A table in that file repeats a column name.");
    seen.add(key);
  }
  return {
    id: value.id,
    name: value.name,
    columns,
    rows: value.rows.map((row) => parseRow(columns, row)),
    createdAt: value.createdAt,
  };
}

function parseDatabase(value: unknown): Database {
  if (!isRecord(value) || !Array.isArray(value.tables)) {
    throw new Error("This file is not a Haris workspace export.");
  }
  if (
    typeof value.id !== "string" ||
    typeof value.name !== "string" ||
    typeof value.description !== "string" ||
    typeof value.createdAt !== "number"
  ) {
    throw new Error("This file is not a Haris workspace export.");
  }
  const name = value.name.trim();
  if (!name || name.length > 80) throw new Error("A database name in that file is not allowed.");
  if (value.description.length > 240) throw new Error("A description in that file is too long.");
  if (value.tables.length > 50) throw new Error("A database in that file has too many tables.");
  const tables = value.tables.map(parseTable).sort(byName);
  const seen = new Set<string>();
  for (const table of tables) {
    const key = table.name.toLowerCase();
    if (seen.has(key)) throw new Error("A database in that file repeats a table name.");
    seen.add(key);
  }
  return {
    id: value.id,
    name,
    description: value.description.trim(),
    tables,
    createdAt: value.createdAt,
  };
}

function parseActivity(value: unknown): Activity[] {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 200).flatMap((item) => {
    if (!isRecord(item)) return [];
    if (typeof item.id !== "string" || typeof item.event !== "string" || typeof item.at !== "number") {
      return [];
    }
    return [{ id: item.id, event: item.event.slice(0, 500), at: item.at }];
  });
}

export function parseWorkspaceExport(value: unknown): Vault {
  if (!isRecord(value) || value.format !== WORKSPACE_FORMAT || value.version !== 1) {
    throw new Error("This file is not a Haris workspace export.");
  }
  if (!Array.isArray(value.databases)) throw new Error("This file is not a Haris workspace export.");
  if (value.databases.length > 100) throw new Error("That export has too many databases.");
  const databases = value.databases.map(parseDatabase).sort(byName);
  const seen = new Set<string>();
  for (const db of databases) {
    const key = db.name.toLowerCase();
    if (seen.has(key)) throw new Error("That export repeats a database name.");
    seen.add(key);
  }
  return { databases, activity: parseActivity(value.activity) };
}

export function parseSealedBackup(value: unknown): AccountFile {
  if (!isRecord(value) || value.format !== SEALED_FORMAT || value.version !== 1) {
    throw new Error("This file is not a sealed Haris vault.");
  }
  if (!isAccountFile(value.account)) throw new Error("This file is not a sealed Haris vault.");
  return value.account;
}

export function formatCell(value: Cell, type: ColumnType): string {
  if (value === null || value === "") return "—";
  if (type === "boolean") return value === true ? "Yes" : "No";
  return String(value);
}
