import { create } from "zustand";
import { openAccount, passwordMatches, rewrapAccount, sealNewAccount, sealVault } from "@/lib/vault-crypto";
import {
  ACCOUNT_KEY,
  IDENT,
  LOCKOUT_KEY,
  byName,
  emptyVault,
  freshLockout,
  isAccountFile,
  type Activity,
  type Cell,
  type Column,
  type Database,
  type DataTable,
  type Lockout,
  type Row,
  type Screen,
  type Vault,
  type AccountFile,
} from "@/lib/vault-types";

type Status = "booting" | "setup" | "locked" | "open";

type State = {
  status: Status;
  busy: boolean;
  account: AccountFile | null;
  vault: Vault;
  dataKey: CryptoKey | null;
  lockout: Lockout;
  screen: Screen;
  hydrate: () => void;
  createAccount: (username: string, password: string) => Promise<void>;
  unlock: (password: string) => Promise<void>;
  lock: () => void;
  erase: () => void;
  changePassword: (current: string, next: string) => Promise<void>;
  go: (screen: Screen) => void;
  createDatabase: (name: string, description: string) => Promise<string>;
  deleteDatabase: (id: string) => Promise<void>;
  createTable: (databaseId: string, name: string, columns: { name: string; type: Column["type"] }[]) => Promise<string>;
  deleteTable: (databaseId: string, tableId: string) => Promise<void>;
  saveRow: (databaseId: string, tableId: string, rowId: string | null, values: Record<string, Cell>) => Promise<void>;
  deleteRow: (databaseId: string, tableId: string, rowId: string) => Promise<void>;
  replaceWorkspace: (vault: Vault) => Promise<void>;
  restoreSealed: (account: AccountFile) => void;
};

function readLockout(): Lockout {
  try {
    const raw = localStorage.getItem(LOCKOUT_KEY);
    if (!raw) return freshLockout();
    const parsed = JSON.parse(raw) as Partial<Lockout>;
    return {
      failed: Number(parsed.failed) || 0,
      lockedUntil: Number(parsed.lockedUntil) || 0,
      sinceUnlock: Number(parsed.sinceUnlock) || 0,
    };
  } catch {
    return freshLockout();
  }
}

function writeLockout(lockout: Lockout) {
  localStorage.setItem(LOCKOUT_KEY, JSON.stringify(lockout));
}

function readAccount(): AccountFile | null {
  try {
    const raw = localStorage.getItem(ACCOUNT_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    return isAccountFile(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

function writeAccount(account: AccountFile) {
  try {
    localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account));
  } catch {
    throw new Error("Could not save. This browser may be out of storage space.");
  }
}

function withLog(vault: Vault, event: string): Vault {
  const entry: Activity = { id: crypto.randomUUID(), event, at: Date.now() };
  return { ...vault, activity: [entry, ...vault.activity].slice(0, 200) };
}

function requireOpen(state: State) {
  if (!state.account || !state.dataKey || state.status !== "open") {
    throw new Error("The workspace is locked.");
  }
  return { account: state.account, dataKey: state.dataKey, vault: state.vault };
}

export const useVault = create<State>((set, get) => {
  async function commit(vault: Vault, event?: string) {
    const open = requireOpen(get());
    const next = event ? withLog(vault, event) : vault;
    const sealed = await sealVault(open.account, open.dataKey, next);
    writeAccount(sealed);
    set({ account: sealed, vault: next });
  }

  return {
    status: "booting",
    busy: false,
    account: null,
    vault: emptyVault(),
    dataKey: null,
    lockout: freshLockout(),
    screen: { name: "home" },

    hydrate: () => {
      if (get().status !== "booting") return;
      const account = readAccount();
      set({
        account,
        lockout: readLockout(),
        status: account ? "locked" : "setup",
        vault: emptyVault(),
        dataKey: null,
      });
    },

    createAccount: async (username, password) => {
      const trimmed = username.trim();
      if (!trimmed) throw new Error("Enter a username.");
      if (trimmed.length > 40) throw new Error("Use a shorter username.");
      if (password.length < 10) throw new Error("Use at least 10 password characters.");
      set({ busy: true });
      try {
        const created = withLog(emptyVault(), "Administrator account created");
        const { account } = await sealNewAccount(trimmed, password, created);
        writeAccount(account);
        writeLockout(freshLockout());
        set({
          account,
          status: "locked",
          busy: false,
          dataKey: null,
          vault: emptyVault(),
          lockout: freshLockout(),
          screen: { name: "home" },
        });
      } catch (error) {
        set({ busy: false });
        if (error instanceof Error && error.message.startsWith("Could not save")) throw error;
        throw new Error("Could not create the account.");
      }
    },

    unlock: async (password) => {
      const account = get().account ?? readAccount();
      if (!account) {
        set({ status: "setup", account: null });
        throw new Error("Create an administrator account first.");
      }
      const lockout = get().lockout;
      if (Date.now() < lockout.lockedUntil) {
        throw new Error("Too many attempts. Wait a little and try again.");
      }
      set({ busy: true });
      try {
        const opened = await openAccount(account, password);
        if (!opened) {
          const failed = lockout.failed + 1;
          const sinceUnlock = lockout.sinceUnlock + 1;
          const next: Lockout =
            failed >= 5
              ? { failed: 0, lockedUntil: Date.now() + 30_000, sinceUnlock }
              : { failed, lockedUntil: 0, sinceUnlock };
          writeLockout(next);
          set({ busy: false, lockout: next, account });
          throw new Error("Sign-in failed. Check your details.");
        }
        let vault = opened.vault;
        if (lockout.sinceUnlock > 0) {
          const count = lockout.sinceUnlock;
          vault = withLog(
            vault,
            count === 1 ? "1 failed sign-in attempt" : `${count} failed sign-in attempts`,
          );
        }
        vault = withLog(vault, "Signed in");
        const sealed = await sealVault(account, opened.key, vault);
        writeAccount(sealed);
        const cleared = freshLockout();
        writeLockout(cleared);
        set({
          status: "open",
          busy: false,
          account: sealed,
          dataKey: opened.key,
          vault,
          lockout: cleared,
          screen: { name: "home" },
        });
      } catch (error) {
        set({ busy: false });
        throw error;
      }
    },

    lock: () => {
      const account = readAccount();
      set({
        status: account ? "locked" : "setup",
        account,
        dataKey: null,
        vault: emptyVault(),
        screen: { name: "home" },
        busy: false,
      });
    },

    erase: () => {
      localStorage.removeItem(ACCOUNT_KEY);
      localStorage.removeItem(LOCKOUT_KEY);
      set({
        status: "setup",
        account: null,
        dataKey: null,
        vault: emptyVault(),
        lockout: freshLockout(),
        screen: { name: "home" },
        busy: false,
      });
    },

    changePassword: async (current, next) => {
      const open = requireOpen(get());
      if (next.length < 10) throw new Error("Use at least 10 characters for the new password.");
      set({ busy: true });
      try {
        const ok = await passwordMatches(open.account, current);
        if (!ok) {
          set({ busy: false });
          throw new Error("Current password is incorrect.");
        }
        const rewrapped = await rewrapAccount(open.account, open.dataKey, next);
        const logged = withLog(open.vault, "Administrator password changed");
        const sealed = await sealVault(rewrapped, open.dataKey, logged);
        writeAccount(sealed);
        set({ account: sealed, vault: logged, busy: false });
      } catch (error) {
        set({ busy: false });
        throw error;
      }
    },

    go: (screen) => set({ screen }),

    createDatabase: async (nameRaw, descriptionRaw) => {
      const name = nameRaw.trim();
      const description = descriptionRaw.trim();
      if (!name) throw new Error("Enter a database name.");
      if (name.length > 80) throw new Error("Use a shorter database name.");
      if (description.length > 240) throw new Error("Use a shorter description.");
      const { vault } = requireOpen(get());
      if (vault.databases.length >= 100) throw new Error("This workspace already has 100 databases.");
      if (vault.databases.some((db) => db.name.toLowerCase() === name.toLowerCase())) {
        throw new Error("That database name already exists.");
      }
      const id = crypto.randomUUID();
      const database: Database = { id, name, description, tables: [], createdAt: Date.now() };
      await commit(
        { ...vault, databases: [...vault.databases, database].sort(byName) },
        `Database created: ${name}`,
      );
      return id;
    },

    deleteDatabase: async (id) => {
      const { vault } = requireOpen(get());
      const database = vault.databases.find((item) => item.id === id);
      if (!database) return;
      await commit(
        { ...vault, databases: vault.databases.filter((item) => item.id !== id) },
        `Database deleted: ${database.name}`,
      );
    },

    createTable: async (databaseId, nameRaw, columnsRaw) => {
      const name = nameRaw.trim();
      if (!IDENT.test(name)) {
        throw new Error("Use a letter first, then letters, numbers, or underscore.");
      }
      if (columnsRaw.length < 1 || columnsRaw.length > 12) {
        throw new Error("Add between 1 and 12 columns.");
      }
      const columns: Column[] = [];
      const seen = new Set<string>();
      for (const column of columnsRaw) {
        const columnName = column.name.trim();
        if (!IDENT.test(columnName)) {
          throw new Error("Column names start with a letter, then letters, numbers, or underscore.");
        }
        const key = columnName.toLowerCase();
        if (seen.has(key)) throw new Error("Column names must be unique.");
        seen.add(key);
        columns.push({ id: crypto.randomUUID(), name: columnName, type: column.type });
      }
      const { vault } = requireOpen(get());
      const database = vault.databases.find((item) => item.id === databaseId);
      if (!database) throw new Error("That database is no longer here.");
      if (database.tables.length >= 50) throw new Error("This database already has 50 tables.");
      if (database.tables.some((table) => table.name.toLowerCase() === name.toLowerCase())) {
        throw new Error("That table already exists.");
      }
      const id = crypto.randomUUID();
      const table: DataTable = { id, name, columns, rows: [], createdAt: Date.now() };
      await commit(
        {
          ...vault,
          databases: vault.databases.map((item) =>
            item.id === databaseId ? { ...item, tables: [...item.tables, table].sort(byName) } : item,
          ),
        },
        `Table created: ${database.name} / ${name}`,
      );
      return id;
    },

    deleteTable: async (databaseId, tableId) => {
      const { vault } = requireOpen(get());
      const database = vault.databases.find((item) => item.id === databaseId);
      const table = database?.tables.find((item) => item.id === tableId);
      if (!database || !table) return;
      await commit(
        {
          ...vault,
          databases: vault.databases.map((item) =>
            item.id === databaseId ? { ...item, tables: item.tables.filter((entry) => entry.id !== tableId) } : item,
          ),
        },
        `Table deleted: ${database.name} / ${table.name}`,
      );
    },

    saveRow: async (databaseId, tableId, rowId, values) => {
      const { vault } = requireOpen(get());
      const database = vault.databases.find((item) => item.id === databaseId);
      const table = database?.tables.find((item) => item.id === tableId);
      if (!database || !table) throw new Error("That table is no longer here.");
      const now = Date.now();
      let event = `Record added in ${database.name} / ${table.name}`;
      const rows = rowId
        ? table.rows.map((row) => {
            if (row.id !== rowId) return row;
            event = `Record edited in ${database.name} / ${table.name}`;
            return { ...row, values, updatedAt: now };
          })
        : [
            { id: crypto.randomUUID(), values, createdAt: now, updatedAt: now } satisfies Row,
            ...table.rows,
          ];
      if (!rowId && table.rows.length >= 2000) throw new Error("This table already has 2,000 records.");
      await commit(
        {
          ...vault,
          databases: vault.databases.map((item) =>
            item.id !== databaseId
              ? item
              : {
                  ...item,
                  tables: item.tables.map((entry) => (entry.id === tableId ? { ...entry, rows } : entry)),
                },
          ),
        },
        event,
      );
    },

    deleteRow: async (databaseId, tableId, rowId) => {
      const { vault } = requireOpen(get());
      const database = vault.databases.find((item) => item.id === databaseId);
      const table = database?.tables.find((item) => item.id === tableId);
      if (!database || !table) return;
      await commit(
        {
          ...vault,
          databases: vault.databases.map((item) =>
            item.id !== databaseId
              ? item
              : {
                  ...item,
                  tables: item.tables.map((entry) =>
                    entry.id === tableId ? { ...entry, rows: entry.rows.filter((row) => row.id !== rowId) } : entry,
                  ),
                },
          ),
        },
        `Record deleted in ${database.name} / ${table.name}`,
      );
    },

    replaceWorkspace: async (incoming) => {
      const logged = withLog(incoming, "Workspace imported from JSON");
      await commit(logged);
    },

    restoreSealed: (account) => {
      writeAccount(account);
      writeLockout(freshLockout());
      set({
        status: "locked",
        account,
        dataKey: null,
        vault: emptyVault(),
        lockout: freshLockout(),
        screen: { name: "home" },
        busy: false,
      });
    },
  };
});
