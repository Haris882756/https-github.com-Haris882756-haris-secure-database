import {
  emptyVault,
  isAccountFile,
  type AccountFile,
  type Vault,
} from "@/lib/vault-types";

const ITERATIONS = 210_000;

function asBuffer(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

function randomBytes(size: number): Uint8Array {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return bytes;
}

function encodeBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let index = 0; index < bytes.length; index += chunk) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
  }
  return btoa(binary);
}

function decodeBase64(value: string): Uint8Array {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

export function constantTimeEquals(a: string, b: string): boolean {
  const length = Math.max(a.length, b.length);
  let diff = a.length ^ b.length;
  for (let index = 0; index < length; index += 1) {
    diff |= (a.charCodeAt(index) || 0) ^ (b.charCodeAt(index) || 0);
  }
  return diff === 0;
}

async function importPassword(password: string) {
  return crypto.subtle.importKey("raw", asBuffer(new TextEncoder().encode(password)), "PBKDF2", false, [
    "deriveBits",
    "deriveKey",
  ]);
}

async function stretchBits(password: string, salt: Uint8Array): Promise<Uint8Array> {
  const key = await importPassword(password);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: asBuffer(salt), iterations: ITERATIONS, hash: "SHA-256" },
    key,
    256,
  );
  return new Uint8Array(bits);
}

async function stretchAes(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const key = await importPassword(password);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt: asBuffer(salt), iterations: ITERATIONS, hash: "SHA-256" },
    key,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

async function aesEncrypt(key: CryptoKey, iv: Uint8Array, data: Uint8Array): Promise<Uint8Array> {
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv: asBuffer(iv) }, key, asBuffer(data));
  return new Uint8Array(encrypted);
}

async function aesDecrypt(key: CryptoKey, iv: Uint8Array, data: Uint8Array): Promise<Uint8Array> {
  const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: asBuffer(iv) }, key, asBuffer(data));
  return new Uint8Array(decrypted);
}

function isVault(value: unknown): value is Vault {
  if (typeof value !== "object" || value === null) return false;
  const vault = value as Vault;
  return Array.isArray(vault.databases) && Array.isArray(vault.activity);
}

async function encryptVault(key: CryptoKey, vault: Vault): Promise<{ vaultIv: string; vault: string }> {
  const iv = randomBytes(12);
  const payload = new TextEncoder().encode(JSON.stringify(vault));
  const sealed = await aesEncrypt(key, iv, payload);
  return { vaultIv: encodeBase64(iv), vault: encodeBase64(sealed) };
}

export async function sealNewAccount(username: string, password: string, vault: Vault = emptyVault()): Promise<{
  account: AccountFile;
  key: CryptoKey;
}> {
  const passSalt = randomBytes(16);
  const wrapSalt = randomBytes(16);
  const passHash = await stretchBits(password, passSalt);
  const dataKey = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
  const raw = new Uint8Array(await crypto.subtle.exportKey("raw", dataKey));
  const wrapKey = await stretchAes(password, wrapSalt);
  const wrapIv = randomBytes(12);
  const wrapped = await aesEncrypt(wrapKey, wrapIv, raw);
  const sealed = await encryptVault(dataKey, vault);
  return {
    key: dataKey,
    account: {
      version: 1,
      username,
      passSalt: encodeBase64(passSalt),
      passHash: encodeBase64(passHash),
      wrapSalt: encodeBase64(wrapSalt),
      wrapIv: encodeBase64(wrapIv),
      wrappedKey: encodeBase64(wrapped),
      vaultIv: sealed.vaultIv,
      vault: sealed.vault,
    },
  };
}

export async function passwordMatches(account: AccountFile, password: string): Promise<boolean> {
  const hash = encodeBase64(await stretchBits(password, decodeBase64(account.passSalt)));
  return constantTimeEquals(hash, account.passHash);
}

export async function openAccount(
  account: AccountFile,
  password: string,
): Promise<{ key: CryptoKey; vault: Vault } | null> {
  if (!(await passwordMatches(account, password))) return null;
  const wrapKey = await stretchAes(password, decodeBase64(account.wrapSalt));
  let raw: Uint8Array;
  try {
    raw = await aesDecrypt(wrapKey, decodeBase64(account.wrapIv), decodeBase64(account.wrappedKey));
  } catch {
    throw new Error("The vault could not be unlocked.");
  }
  const dataKey = await crypto.subtle.importKey("raw", asBuffer(raw), { name: "AES-GCM" }, true, [
    "encrypt",
    "decrypt",
  ]);
  let plain: Uint8Array;
  try {
    plain = await aesDecrypt(dataKey, decodeBase64(account.vaultIv), decodeBase64(account.vault));
  } catch {
    throw new Error("The vault could not be read.");
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(new TextDecoder().decode(plain));
  } catch {
    throw new Error("The vault could not be read.");
  }
  if (!isVault(parsed)) throw new Error("The vault could not be read.");
  return { key: dataKey, vault: parsed };
}

export async function sealVault(account: AccountFile, key: CryptoKey, vault: Vault): Promise<AccountFile> {
  const sealed = await encryptVault(key, vault);
  return { ...account, vaultIv: sealed.vaultIv, vault: sealed.vault };
}

export async function rewrapAccount(account: AccountFile, dataKey: CryptoKey, password: string): Promise<AccountFile> {
  const passSalt = randomBytes(16);
  const wrapSalt = randomBytes(16);
  const passHash = await stretchBits(password, passSalt);
  const raw = new Uint8Array(await crypto.subtle.exportKey("raw", dataKey));
  const wrapKey = await stretchAes(password, wrapSalt);
  const wrapIv = randomBytes(12);
  const wrapped = await aesEncrypt(wrapKey, wrapIv, raw);
  return {
    ...account,
    passSalt: encodeBase64(passSalt),
    passHash: encodeBase64(passHash),
    wrapSalt: encodeBase64(wrapSalt),
    wrapIv: encodeBase64(wrapIv),
    wrappedKey: encodeBase64(wrapped),
  };
}

export function readStoredAccount(): AccountFile | null {
  try {
    const raw = localStorage.getItem("haris.account.v1");
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    return isAccountFile(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
