import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { BackupScreen } from "@/components/backup";
import { BootScreen, LoginScreen, SetupScreen } from "@/components/gate";
import { SecurityScreen } from "@/components/security";
import { Shell } from "@/components/shell";
import { DatabaseScreen, HomeScreen, RecordsScreen } from "@/components/workspace";
import { useVault } from "@/lib/vault-store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const status = useVault((state) => state.status);
  const screen = useVault((state) => state.screen);
  const hydrate = useVault((state) => state.hydrate);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  let body;
  if (status === "booting") body = <BootScreen />;
  else if (status === "setup") body = <SetupScreen />;
  else if (status === "locked") body = <LoginScreen />;
  else {
    body = (
      <Shell>
        {screen.name === "home" && <HomeScreen />}
        {screen.name === "database" && <DatabaseScreen id={screen.id} />}
        {screen.name === "records" && (
          <RecordsScreen databaseId={screen.databaseId} tableId={screen.tableId} />
        )}
        {screen.name === "settings" && <SecurityScreen />}
        {screen.name === "backup" && <BackupScreen />}
      </Shell>
    );
  }

  return (
    <>
      {body}
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "var(--color-card)",
            color: "var(--color-ink)",
            border: "1px solid var(--color-line)",
          },
        }}
      />
    </>
  );
}
